**Estrategia de financiamiento de la República Dominicana**

########### 1 Tabla de Contenido

Acrónimos y Siglas	6

Resumen Ejecutivo	15

Capítulo 1. Introducción y contexto económico y financiero	31

Sección 1.1. Contexto Económico y Financiero de la República Dominicana	31

Sección 1.2. Estabilidad del Sector Financiero de la República Dominicana	44

Sección 1.3. Riesgos para el Desarrollo en la República Dominicana	49

Capítulo 2. Finanzas públicas domésticas: el motor del desarrollo sostenible	65

Sección 2.1. Ingresos y Gastos del Gobierno nacional	66

Sección 2.2. Análisis sobre la sostenibilidad de la deuda pública	91

Sección 2.3. Sistema Nacional de Inversión Pública	109

Sección 2.4. Flujos Financieros Ilícitos	129

Sección 2.5. Recomendaciones clave: fortaleciendo la eficiencia fiscal	144

Capítulo 3. Finanzas públicas internacionales: motor de innovación y catalizador del desarrollo sostenible	165

Sección 3.1. Sistema Nacional de Cooperación Internacional	167

Sección 3.2. Cooperación reembolsable y no reembolsable	183

Sección 3.3. Cooperación Sur-Sur y Triangular para el Desarrollo	216

Sección 3.4. Eficacia de la Cooperación Internacional para el Desarrollo	231

Sección 3.5. Financiamiento Verde y Climático en la República Dominicana	248

Sección 3.6. Recomendaciones clave: de la cooperación receptiva a la gestión estratégica de alianzas	269

Capítulo 4. Financiamiento Privado Doméstico: Palanca de Inversión y Multiplicador del Desarrollo Sostenible	291

Sección 4.1. Desarrollo del sector privado y financiamiento de las MIPYMES	292

Sección 4.2. Desarrollo del Sector Financiero Doméstico y Mercados de Capitales	316

Sección 4.3. Financiamiento Mixto y Asociaciones Público-Privadas	339

Sección 4.4. Inversión de Impacto y Filantropía	356

Sección 4.5. Recomendaciones Clave: Movilizando el Capital Privado Doméstico hacia un Ecosistema Financiero Incluyente y Sostenible	381

Capítulo 5. Financiamiento Privado Internacional: Integración Global y Habilitador de Transformación Productiva	403

Sección 5.1. Inversión Extranjera Directa e Integración Productiva	404

Sección 5.2. Comercio internacional y financiamiento exportador	437

Sección 5.3. Finanzas de la Diáspora y Remesas	458

Sección 5.4. Inversión de Impacto Internacional	476

Sección 5.5. Recomendaciones Clave: Convirtiendo los Flujos Privados Internacionales en Palancas de Transformación Productiva	492

Capítulo 6. Instrumentos Alternativos de Financiamiento	511

Capítulo 7. Gobernanza, Monitoreo y Evaluación de la Estrategia de Financiamiento para el Desarrollo	519

Referencias	529

########### 2 Listado de Figuras

**Figura 1. Producto Interno Bruto (Precios constantes)	32**

**Figura 2. Crecimiento económico real en América Latina y el Caribe	33**

**Figura 3. Tasa de desocupación abierta	34**

**Figura 4. Tasa de Inflación Interanual	35**

**Figura 5. Tasa de Intervención de Política Monetaria	35**

**Figura 6. Balanza comercial	36**

**Figura 7. Balanza de servicios	37**

**Figura 8. Pobreza monetaria e Inequidad	38**

**Figura 9. Tasa promedio de compra del dólar de referencia del mercado spot - mensual	43**

**Figura 10. Crédito total al sector privado no financiero	45**

**Figura 11. Total depósitos y valores distintos de acciones	46**

**Figura 12. Primas netas cobradas por seguros	48**

**Figura 13. Alineación del Presupuesto General del Estado 2024 a ODS (Devengado – dic 2024)	81**

**Figura 14. Deuda del Sector Público No Financiero (SPNF)	93**

**Figura 15. Composición de la deuda por fuente y acreedor (superior), moneda (inferior izquierda) y tipo de interés (inferior derecha)—cifras en USD y % del total de la deuda del SPNF	96**

**Figura 16. Proyectos de Inversión Pública por tipología, programado 2025-2028	115**

**Figura 17. Alineación del PNPIP 2025-2028 con los ejes de la END 2030	115**

**Figura 18. Ayuda Oficial al Desarrollo en Centroamérica y el Caribe, 2024	184**

**Figura 19. Ayuda Oficial para el Desarrollo recibida por RD (USD Constantes 2023)	185**

**Figura 20. Ayuda Oficial para el Desarrollo enviada a RD por donante entre 2021-2024 (USD millones)	186**

**Figura 21. Ayuda Oficial para el Desarrollo entre 2021-2024 alineada con END (USD millones)	187**

**Figura 22. Participación de la República Dominicana en Cooperación SSyT	219**

**Figura 23. Número de empresas según clasificación de MIPYME 2012-2024	293**

**Figura 24. Crédito interno al sector privado como proporción del PIB: comparación regional, 2014 y 2024	318**

**Figura 25. Crédito total al sector privado no financiero como proporción del PIB	321**

**Figura 26. Participación del sector público y privado en el mercado de valores dominicano, 2014-2024	322**

**Figura 27. Evolución de la Capitalización Individual (CCI) y su participación en el PIB, 2014–2024	327**

**Figura 28. Composición porcentual de la cartera de los Fondos de Pensiones, 2017 y 2024	328**

**Figura 29. Comportamiento de la Inversión Extranjera Directa (IED) 2015-2025	406**

**Figura 30. Balanza comercial	439**

**Figura 31. Balanza de pago de la República Dominicana, 2015-2025	440**

**Figura 32. Balanza de servicios	440**

**Figura 33. Flujos de remesas familiares 2015-2025 por país emisor	460**

########### 3 Listado de Tablas

**Tabla 1. Estimaciones macroeconómicas del MFMP 2024-2028	41**

**Tabla 2. Marco Financiero Plurianual 2024-2028 (% del PIB)	42**

**Tabla 3. Matriz de riesgos para el financiamiento para el desarrollo	61**

**Tabla 4. Partidas de Ingreso del Marco Financiero Plurianual 2025-2029 (Millones de RD$ y % del PIB)	68**

**Tabla 5. Partidas de Gasto del Marco Financiero Plurianual 2025-2029 (Millones de RD$ y % del PIB)	76**

**Tabla 6. Clasificación Funcional del Gasto del Gobierno Central 2025-2028 (Millones de RD$ y % del PIB)	78**

**Tabla 7. Resultados de IPP: Consideraciones para estudio de Gobierno	83**

**Tabla 8. Consolidación de recomendaciones sobre el financiamiento público doméstico	162**

**Tabla 9. Espacios de Coordinación del Sistema Nacional de Cooperación Internacional	172**

Tabla 10. Marco de prioridades del PNPCI	176

**Tabla 10. Agencias, Fondos y Programas (AFPs) del Sistema de Naciones Unidas en la República Dominicana	197**

**Tabla 11. Alineación de principales cooperantes en la República Dominicana con los objetivos generales de la END	214**

**Tabla 12. Catálogo Dominicano de Oferta de Cooperación Técnica	224**

**Tabla 14. Iniciativas de Financiamiento Verde y Climático en la República Dominicana	254**

**Tabla 14. Consolidación de recomendaciones sobre el financiamiento público internacional	288**

**Tabla 15. Principales indicadores de la cartera de crédito destinada a MIPYMES (marzo-2025)	309**

**Tabla 16. Evolución de los depósitos del sector privado y su relación con el PIB, 2014–2024	321**

**Tabla 17. Segmentos representativos de la curva de rendimiento soberana del mercado doméstico	324**

**Tabla 18. Stock de valores en custodia por tipo de instrumento, 2024	325**

**Tabla 19. Actores clave del ecosistema de filantropía e inversión de impacto en la República Dominicana	360**

**Tabla 20. Consolidación de recomendaciones sobre el financiamiento privado doméstico	401**

**Tabla 21. Principales países de origen de la IED en República Dominicana	407**

**Tabla 22. Distribución sectorial de la IED en República Dominicana	408**

**Tabla 23. Principales instrumentos legales del régimen de incentivos a la IED en República Dominicana (Vigentes a 2025)	416**

**Tabla 24. Matriz de recomendaciones estratégicas: priorización y responsabilidad institucional	436**

**Tabla 25. Balanza de Servicios 2014-2024	441**

**Tabla 26. Principales productos exportados desde República Dominicana, 2024	442**

**Tabla 27. Principales productos exportados bajo el régimen nacional, 2024	442**

**Tabla 28. Principales productos importados a República Dominicana, 2024	442**

**Tabla 29. Principales instrumentos de incentivos al comercio internacional, en República Dominicana	446**

**Tabla 30. Costos estimados de envío de remesas hacia la República Dominicana por tipo de canal y corredores principales (2023-2025)	462**

**Tabla 31. Actores internacionales de inversión de impacto y su perfil de intervención	479**

**Tabla 32. Consolidación de recomendaciones sobre el financiamiento privado internacional	509**

## 1 Acrónimos y Siglas

| **ABA**          | Asociación de Bancos Múltiples de la República Dominicana                                                                                       |
|------------------|-------------------------------------------------------------------------------------------------------------------------------------------------|
| **ABM**          | Agent-Based Modeling (Modelación Basada en Agentes)                                                                                             |
| **ACP**          | Acuerdo Plurilateral sobre Contratación Pública                                                                                                 |
| **ADB**          | Asian Development Bank (Banco Asiático de Desarrollo)                                                                                           |
| **ADD**          | Alianza para el Desarrollo en Democracia                                                                                                        |
| **ADOSAFI**      | Asociación Dominicana de Sociedades Administradoras de Fondos de Inversión                                                                      |
| **ADOZONA**      | Asociación Dominicana de Zonas Francas                                                                                                          |
| **AECID**        | Agencia Española de Cooperación Internacional para el Desarrollo                                                                                |
| **AEOI**         | Automatic Exchange of Information (Intercambio Automático de Información)                                                                       |
| **AFD**          | Agence Française de Développement (Agencia Francesa de Desarrollo)                                                                              |
| **AFI**          | Alliance for Financial Inclusion (Alianza para la Inclusión Financiera)                                                                         |
| **AFP**          | Administradoras de Fondos de Pensiones                                                                                                          |
| **AGCED**        | Alianza Global para una Cooperación al Desarrollo Eficaz                                                                                        |
| **AGCID**        | Agencia Chilena de Cooperación Internacional para el Desarrollo                                                                                 |
| **AIRAC**        | Asociación de Instituciones Rurales de Ahorro y Crédito                                                                                         |
| **AIRD**         | Asociación de Industrias de la República Dominicana                                                                                             |
| **ALA**          | Antilavado de Activos                                                                                                                           |
| **ALC**          | América Latina y el Caribe                                                                                                                      |
| **ALFI**         | Aplicación gamificada de educación financiera rural (ALFI fintech)                                                                              |
| **AMF**          | Autoriteit Financiële Markten (Autoridad de Mercados Financieros de los Países Bajos)                                                           |
| **AMIC**         | Acuerdo sobre Medidas en materia de Inversiones relacionadas con el Comercio                                                                    |
| **AMV**          | Autorregulador del Mercado de Valores (Colombia)                                                                                                |
| **ANJE**         | Asociación Nacional de Jóvenes Empresarios                                                                                                      |
| **AOD**          | Ayuda Oficial al Desarrollo                                                                                                                     |
| **APA**          | Acuerdos de Precios Anticipados                                                                                                                 |
| **APD**          | Auditoría Posterior al Despacho                                                                                                                 |
| **APP**          | Alianzas Público-Privadas                                                                                                                       |
| **APPD**         | Alianzas Público-Privadas para el Desarrollo Sostenible                                                                                         |
| **ARIZ**         | Garantía bancaria para el acceso al crédito de las PYMES (programa de la AFD)                                                                   |
| **ASFL**         | Asociaciones Sin Fines de Lucro                                                                                                                 |
| **ASG**          | Ambiental, Social y de Gobernanza                                                                                                               |
| **ASIEX**        | Asociación de Empresas de Inversión Extranjera                                                                                                  |
| **AUM**          | Assets Under Management (Activos bajo Gestión)                                                                                                  |
| **B2B**          | Business-to-Business (Negocio a Negocio)                                                                                                        |
| **BAC**          | Banco de América Central                                                                                                                        |
| **BCIE**         | Banco Centroamericano de Integración Económica                                                                                                  |
| **BCRD**         | Banco Central de la República Dominicana                                                                                                        |
| **BEI**          | Banco Europeo de Inversiones                                                                                                                    |
| **BEPS**         | Base Erosion and Profit Shifting (Erosión de la Base Imponible y Traslado de Beneficios)                                                        |
| **BID**          | Banco Interamericano de Desarrollo                                                                                                              |
| **BIRF**         | Banco Internacional de Reconstrucción y Fomento                                                                                                 |
| **BIS**          | Bank for International Settlements (Banco de Pagos Internacionales)                                                                             |
| **BM**           | Banco Mundial                                                                                                                                   |
| **BPO**          | Business Process Outsourcing (Tercerización de Procesos de Negocios)                                                                            |
| **BSDC**         | Business & Sustainable Development Commission (Comisión de Negocios y Desarrollo Sostenible)                                                    |
| **BVRD**         | Bolsa de Valores de la República Dominicana                                                                                                     |
| **C-PIMA**       | Climate Public Investment Management Assessment (Evaluación de la Gestión de la Inversión Pública para el Cambio Climático)                     |
| **CAD-OCDE**     | Comité de Ayuda al Desarrollo de la OCDE                                                                                                        |
| **CADOAR**       | Cámara Dominicana de Aseguradores y Reaseguradores                                                                                              |
| **CAF**          | Banco de Desarrollo de América Latina y el Caribe                                                                                               |
| **CAPEX**        | Capital Expenditure (Gasto de Capital)                                                                                                          |
| **CAPTAC-DR**    | Centro de Asistencia Técnica Regional para Centroamérica, Panamá y República Dominicana                                                         |
| **CASFL**        | Centro Nacional de Fomento y Promoción de las Asociaciones Sin Fines de Lucro                                                                   |
| **CAT-DDO**      | Catastrophe Deferred Drawdown Option (Opción de Desembolso Diferido ante Catástrofes)                                                           |
| **CCE**          | Centro Cultural de España                                                                                                                       |
| **CCF**          | Contingent Credit Facility (Facilidad de Crédito Contingente)                                                                                   |
| **CCI**          | Cuenta de Capitalización Individual                                                                                                             |
| **CCRIF**        | Caribbean Catastrophe Risk Insurance Facility (Mecanismo de Seguro contra Riesgos de Catástrofe en el Caribe)                                   |
| **CDE**          | Centros de Desarrollo Empresarial                                                                                                               |
| **CEPAL**        | Comisión Económica para América Latina y el Caribe                                                                                              |
| **CES**          | Consejo Económico y Social                                                                                                                      |
| **CFT**          | Combating the Financing of Terrorism (Combate al Financiamiento del Terrorismo)                                                                 |
| **CIAT**         | Centro Interamericano de Administraciones Tributarias                                                                                           |
| **CIF**          | Cost, Insurance, and Freight (Costo, Seguro y Flete)                                                                                            |
| **CNAPP**        | Consejo Nacional de Alianzas Público-Privadas                                                                                                   |
| **CNC**          | Consejo Nacional de Competitividad                                                                                                              |
| **CNCCMDL**      | Consejo Nacional para el Cambio Climático y Mecanismo de Desarrollo Limpio                                                                      |
| **CNSS**         | Consejo Nacional de Seguridad Social                                                                                                            |
| **CNZFE**        | Consejo Nacional de Zonas Francas de Exportación                                                                                                |
| **COE**          | Centro de Operaciones de Emergencias                                                                                                            |
| **CONEP**        | Consejo Nacional de la Empresa Privada                                                                                                          |
| **CONFOTUR**     | Consejo Nacional de Fomento Turístico                                                                                                           |
| **CORFO**        | Corporación de Fomento de la Producción (Chile)                                                                                                 |
| **CP**           | Corto Plazo                                                                                                                                     |
| **CPI**          | Compra Pública de Innovación                                                                                                                    |
| **CREES**        | Centro Regional de Estrategias Económicas Sostenibles                                                                                           |
| **CRS**          | Common Reporting Standard (Estándar Común de Reporte)                                                                                           |
| **CSS**          | Cooperación Sur-Sur                                                                                                                             |
| **CT**           | Cooperación Triangular                                                                                                                          |
| **CTI**          | Ciencia, Tecnología e Innovación                                                                                                                |
| **CUT**          | Cuenta Única del Tesoro                                                                                                                         |
| **DACCI**        | Dirección de Análisis y Coordinación de la Cooperación Internacional                                                                            |
| **DBFOM**        | Design, Build, Finance, Operate, and Maintain (Diseño, Construcción, Financiamiento, Operación y Mantenimiento)                                 |
| **DDPS**         | Dirección de Desarrollo y Planificación Sectorial                                                                                               |
| **DESA**         | Department of Economic and Social Affairs (Departamento de Asuntos Económicos y Sociales de la ONU)                                             |
| **DFC**          | Development Finance Corporation (Corporación Financiera de Desarrollo Internacional de EE. UU.)                                                 |
| **DGA**          | Dirección General de Aduanas                                                                                                                    |
| **DGAPP**        | Dirección General de Alianzas Público-Privadas                                                                                                  |
| **DGCP**         | Dirección General de Contrataciones Públicas                                                                                                    |
| **DGII**         | Dirección General de Impuestos Internos                                                                                                         |
| **DGIP**         | Dirección General de Inversión Pública                                                                                                          |
| **DGJP**         | Dirección General de Jubilaciones y Pensiones                                                                                                   |
| **DIGEIG**       | Dirección General de Ética e Integridad Gubernamental                                                                                           |
| **DIGEPRES**     | Dirección General de Presupuesto                                                                                                                |
| **DIOR**         | Declaración Informativa de Operaciones entre Relacionados                                                                                       |
| **DNP**          | Departamento Nacional de Planeación (Colombia)                                                                                                  |
| **DNSH**         | Do No Significant Harm (No Causar Daño Significativo)                                                                                           |
| **DPL**          | Préstamos para Políticas de Desarrollo                                                                                                          |
| **DR-CAFTA**     | Dominican Republic-Central America Free Trade Agreement (Tratado de Libre Comercio entre República Dominicana, Centroamérica y Estados Unidos)  |
| **ECSP**         | European Crowdfunding Service Provider (Proveedor Europeo de Servicios de Financiación Participativa)                                           |
| **EDE**          | Empresas Distribuidoras de Electricidad                                                                                                         |
| **EDGE**         | Excellence in Design for Greater Efficiencies                                                                                                   |
| **EFD**          | Estrategia de Financiamiento para el Desarrollo                                                                                                 |
| **EGE**          | Empresa de Generación Eléctrica                                                                                                                 |
| **EIA**          | Estudio de Impacto Ambiental                                                                                                                    |
| **EITI**         | Extractive Industries Transparency Initiative (Iniciativa para la Transparencia de Industrias Extractivas)                                      |
| **EMT**          | Empresa Metropolitana de Transporte                                                                                                             |
| **ENAI**         | Estrategia Nacional de Atracción de Inversión                                                                                                   |
| **ENC**          | Estrategia Nacional de Competitividad                                                                                                           |
| **END**          | Estrategia Nacional de Desarrollo                                                                                                               |
| **ENFIS**        | Estrategia Nacional de Fomento a la Industria de Semiconductores                                                                                |
| **ENHOGAR**      | Encuesta Nacional de Hogares de Propósitos Múltiples                                                                                            |
| **ENIEF**        | Encuesta Nacional de Inclusión y Educación Financiera                                                                                           |
| **ENIF**         | Estrategia Nacional de Inclusión Financiera                                                                                                     |
| **EPC**          | Engineering, Procurement, and Construction (Ingeniería, Adquisiciones y Construcción)                                                           |
| **EPK**          | Principios de Kampala                                                                                                                           |
| **ESCO**         | Energy Service Company (Empresa de Servicios Energéticos)                                                                                       |
| **ESG**          | Environmental, Social, and Governance (Ambiental, Social y Gobernanza)                                                                          |
| **ESMS**         | Environmental and Social Management System (Sistema de Gestión Ambiental y Social)                                                              |
| **ETS**          | Emissions Trading System (Sistema de Comercio de Emisiones)                                                                                     |
| **FAO**          | Food and Agriculture Organization (Organización de las Naciones Unidas para la Alimentación y la Agricultura)                                   |
| **FATCA**        | Foreign Account Tax Compliance Act (Ley de Cumplimiento Fiscal de Cuentas Extranjeras)                                                          |
| **FBR**          | Financiamiento basado en Resultados                                                                                                             |
| **FEDES**        | Fondo Español de Desarrollo Sostenible                                                                                                          |
| **FFD4**         | Cuarta Conferencia Internacional sobre la Financiación para el Desarrollo                                                                       |
| **FFI**          | Flujos Financieros Ilícitos                                                                                                                     |
| **FIAGRO**       | Cadeias Produtivas Agroindustriais (Brasil)                                                                                                     |
| **FIDA**         | Fondo Internacional de Desarrollo Agrícola                                                                                                      |
| **FIPYMI**       | Fondo de Garantía para las Pequeñas y Medianas Industrias                                                                                       |
| **FMI**          | Fondo Monetario Internacional                                                                                                                   |
| **FONPRODE**     | Fondo para la Promoción del Desarrollo                                                                                                          |
| **FPI**          | Financiamiento Público Internacional                                                                                                            |
| **FRAT**         | Fiscal Risk Assessment Tool (Herramienta de Evaluación de Riesgos Fiscales)                                                                     |
| **FSB**          | Financial Stability Board (Consejo de Estabilidad Financiera)                                                                                   |
| **FUNGLODE**     | Fundación Global Democracia y Desarrollo                                                                                                        |
| **FX**           | Foreign Exchange (Mercado de Divisas / Cambio de Divisas)                                                                                       |
| **GAFI**         | Grupo de Acción Financiera Internacional                                                                                                        |
| **GAIA**         | Green and Adaptation Investment Architecture                                                                                                    |
| **GBM**          | Grupo Banco Mundial                                                                                                                             |
| **GCF**          | Green Climate Fund (Fondo Verde del Clima)                                                                                                      |
| **GEI**          | Gases de Efecto Invernadero                                                                                                                     |
| **GFI**          | Global Financial Integrity                                                                                                                      |
| **GFP**          | Gestión Financiera Pública                                                                                                                      |
| **GGGI**         | Global Green Growth Institute (Instituto Global para el Crecimiento Verde)                                                                      |
| **GIIN**         | Global Impact Investing Network (Red Global de Inversión de Impacto)                                                                            |
| **GIZ**          | Deutsche Gesellschaft für Internationale Zusammenarbeit (Agencia Alemana de Cooperación Internacional)                                          |
| **GPEDC**        | Alianza Global para la Cooperación Eficaz al Desarrollo                                                                                         |
| **GRI**          | Global Reporting Initiative (Iniciativa Global de Reporte)                                                                                      |
| **HLO**          | High-level Outcome (Resultados de Alto Nivel)                                                                                                   |
| **HLPF**         | High Level Political Forum (Foro Político de Alto Nivel)                                                                                        |
| **IA**           | Inteligencia Artificial                                                                                                                         |
| **IBP**          | International Budget Partnership (Asociación Internacional de Presupuesto)                                                                      |
| **ICMA**         | International Capital Market Association (Asociación Internacional de Mercados de Capitales)                                                    |
| **IDH**          | Índice de Desarrollo Humano                                                                                                                     |
| **IE**           | Iniciativa Estratégica                                                                                                                          |
| **IED**          | Inversión Extranjera Directa                                                                                                                    |
| **IFC**          | International Finance Corporation (Corporación Financiera Internacional)                                                                        |
| **IFRS**         | International Financial Reporting Standards (Normas Internacionales de Información Financiera)                                                  |
| **IMCD**         | Impuesto Mínimo Complementario Doméstico                                                                                                        |
| **IMG**          | Impuesto Mínimo Global                                                                                                                          |
| **IMP**          | Impact Management Project                                                                                                                       |
| **INAPA**        | Instituto Nacional de Aguas Potables y Alcantarillados                                                                                          |
| **INDEX**        | Instituto de Dominicanos y Dominicanas en el Exterior                                                                                           |
| **INDOCAL**      | Instituto Dominicano para la Calidad                                                                                                            |
| **INDOMET**      | Instituto Dominicano de Meteorología                                                                                                            |
| **INDRHI**       | Instituto Nacional de Recursos Hidráulicos                                                                                                      |
| **INFF**         | Integrated National Financing Framework (Marco Nacional Integrado de Financiamiento)                                                            |
| **INFOTEP**      | Instituto Nacional de Formación Técnico Profesional                                                                                             |
| **INTRANT**      | Instituto Nacional de Tránsito y Transporte Terrestre                                                                                           |
| **INV**          | Informe Nacional Voluntario                                                                                                                     |
| **IOA**          | Investment Opportunity Areas (Áreas de Oportunidad de Inversión)                                                                                |
| **IOSCO**        | Organización Internacional de Comisiones de Valores                                                                                             |
| **IPCC**         | Panel Intergubernamental sobre Cambio Climático                                                                                                 |
| **IPF**          | Investment Project Financing (Financiamiento de Proyectos de Inversión)                                                                         |
| **IPMVP**        | International Performance Measurement and Verification Protocol (Protocolo Internacional de Medición y Verificación de Rendimiento)             |
| **IPO**          | Initial Public Offering (Oferta Pública Inicial)                                                                                                |
| **IPP**          | Inferencia de Prioridades de Política                                                                                                           |
| **IPSI**         | Índice de Priorización Sectorial Integrado                                                                                                      |
| **IRIS**         | Impact Reporting and Investment Standards (Estándares de Inversión y Reporte de Impacto)                                                        |
| **ISC**          | Impuestos Selectivos al Consumo                                                                                                                 |
| **ISO**          | International Organization for Standardization (Organización Internacional de Normalización)                                                    |
| **ISR**          | Impuesto sobre la Renta                                                                                                                         |
| **ISSB**         | Consejo de Normas Internacionales de Sostenibilidad                                                                                             |
| **ITBIS**        | Impuesto sobre Transferencias de Bienes Industrializados y Servicios                                                                            |
| **ITIF**         | Information Technology and Innovation Foundation                                                                                                |
| **ITLA**         | Instituto Tecnológico de Las Américas                                                                                                           |
| **ITSC**         | Instituto Tecnológico Superior Comunitario                                                                                                      |
| **IVA**          | Impuesto al Valor Agregado                                                                                                                      |
| **JICA**         | Japan International Cooperation Agency (Agencia de Cooperación Internacional de Japón)                                                          |
| **KIF**          | Korean Institute of Finance (Instituto Financiero de Corea)                                                                                     |
| **KOICA**        | Korea International Cooperation Agency (Agencia de Cooperación Internacional de Corea)                                                          |
| **KOPIA**        | Korea Program on International Agriculture (Programa de Corea para la Agricultura Internacional)                                                |
| **KYC**          | Know Your Customer (Conoce a tu Cliente)                                                                                                        |
| **LEED**         | Leadership in Energy and Environmental Design                                                                                                   |
| **LP**           | Largo Plazo                                                                                                                                     |
| **LPI**          | Logistic Performance Index (Índice de Desempeño Logístico)                                                                                      |
| **MAAC**         | Multilateral Convention on Mutual Administrative Assistance in Tax Matters (Convención sobre Asistencia Administrativa Mutua en Materia Fiscal) |
| **MAP**          | Marco de Alianza País                                                                                                                           |
| **MAUC**         | Ministerio de Asuntos Exteriores, Unión Europea y Cooperación (España)                                                                          |
| **MBS**          | Mortgage-Backed Securities (Valores Respaldados por Hipotecas)                                                                                  |
| **MCAA**         | Multilateral Competent Authority Agreement (Acuerdo Multilateral de Autoridades Competentes)                                                    |
| **MEPYD**        | Ministerio de Economía, Planificación y Desarrollo                                                                                              |
| **MESCYT**       | Ministerio de Educación Superior, Ciencia y Tecnología                                                                                          |
| **MFD**          | Maximizing Finance for Development (Maximización del Financiamiento para el Desarrollo)                                                         |
| **MFMP**         | Marco Fiscal de Mediano Plazo                                                                                                                   |
| **MGMP**         | Marco de Gasto de Mediano Plazo                                                                                                                 |
| **MH**           | Ministerio de Hacienda                                                                                                                          |
| **MHE**          | Ministerio de Hacienda y Economía                                                                                                               |
| **MICM**         | Ministerio de Industria, Comercio y Mipymes                                                                                                     |
| **MIGA**         | Organismo Multilateral de Garantía de Inversiones                                                                                               |
| **MIMARENA**     | Ministerio de Medio Ambiente y Recursos Naturales                                                                                               |
| **MINERD**       | Ministerio de Educación de la República Dominicana                                                                                              |
| **MINPRE**       | Ministerio de la Presidencia                                                                                                                    |
| **MINTUR**       | Ministerio de Turismo                                                                                                                           |
| **MIP**          | Multiannual Indicative Programme (Programa Indicativo Plurianual)                                                                               |
| **MIPYME**       | Micro, Pequeña y Mediana Empresa                                                                                                                |
| **MIREX**        | Ministerio de Relaciones Exteriores                                                                                                             |
| **MMARN**        | Ministerio de Medio Ambiente y Recursos Naturales                                                                                               |
| **MNA**          | Medidas No Arancelarias                                                                                                                         |
| **MOPC**         | Ministerio de Obras Públicas y Comunicaciones                                                                                                   |
| **MOR**          | Motor de Riesgo                                                                                                                                 |
| **MP**           | Mediano Plazo                                                                                                                                   |
| **MPFP**         | Marco de Programación Fiscal Plurianual                                                                                                         |
| **MRV**          | Medición, Reporte y Verificación                                                                                                                |
| **MSF**          | Medidas Sanitarias y Fitosanitarias                                                                                                             |
| **MW**           | Megawatts (Megavatios)                                                                                                                          |
| **NAB**          | National Advisory Board (Consejo Asesor Nacional)                                                                                               |
| **NAFIN**        | Nacional Financiera (México)                                                                                                                    |
| **NCF**          | Número de Comprobante Fiscal                                                                                                                    |
| **NDC**          | Nationally Determined Contributions (Contribuciones Nacionalmente Determinadas)                                                                 |
| **NIIF**         | Normas Internacionales de Información Financiera                                                                                                |
| **OBBBA**        | One Big Beautiful Bill Act (Ley de EE. UU.)                                                                                                     |
| **OCDE**         | Organización para la Cooperación y el Desarrollo Económico                                                                                      |
| **OCR**          | Oficina de la Coordinadora Residente                                                                                                            |
| **ODS**          | Objetivos de Desarrollo Sostenible                                                                                                              |
| **OEA**          | Operador Económico Autorizado                                                                                                                   |
| **OMA**          | Organización Mundial de Aduanas                                                                                                                 |
| **OMC**          | Organización Mundial del Comercio                                                                                                               |
| **OMS**          | Organización Mundial de la Salud                                                                                                                |
| **ONE**          | Oficina Nacional de Estadística                                                                                                                 |
| **ONGD**         | Organización No Gubernamental para el Desarrollo                                                                                                |
| **ONU**          | Organización de las Naciones Unidas                                                                                                             |
| **OPS**          | Organización Panamericana de la Salud                                                                                                           |
| **OSC**          | Organizaciones de la Sociedad Civil                                                                                                             |
| **OTC**          | Obstáculos Técnicos al Comercio                                                                                                                 |
| **PAI**          | Principal Adverse Impacts (Principales Impactos Adversos)                                                                                       |
| **PBL**          | Policy-Based Loan (Préstamo Basado en Políticas)                                                                                                |
| **PCG**          | Garantías Parciales de Crédito                                                                                                                  |
| **PCID**         | Política de Cooperación Internacional para el Desarrollo                                                                                        |
| **PDA**          | Portafolio de Demanda Agregada                                                                                                                  |
| **PEFA**         | Public Expenditure and Financial Accountability (Gasto Público y Rendición de Cuentas Financieras)                                              |
| **PEI**          | Plan Estratégico Institucional                                                                                                                  |
| **PFM**          | Public Financial Management (Gestión Financiera Pública)                                                                                        |
| **PGE**          | Presupuesto General del Estado                                                                                                                  |
| **PIAC**         | Plan de Inversión para la Acción Climática                                                                                                      |
| **PIB**          | Producto Interno Bruto                                                                                                                          |
| **PIMA**         | Public Investment Management Assessment (Evaluación de la Gestión de la Inversión Pública)                                                      |
| **PLANGIR**      | Plan Nacional de Gestión Integral de Residuos Sólidos                                                                                           |
| **PMA**          | Programa Mundial de Alimentos                                                                                                                   |
| **PNACC-RD**     | Plan Nacional de Adaptación al Cambio Climático                                                                                                 |
| **PNFE**         | Plan Nacional de Fomento de las Exportaciones                                                                                                   |
| **PNPCI**        | Plan Nacional Plurianual de Cooperación Internacional                                                                                           |
| **PNPIP**        | Plan Nacional Plurianual de Inversión Pública                                                                                                   |
| **PNPSP**        | Plan Nacional Plurianual del Sector Público                                                                                                     |
| **PNUD**         | Programa de las Naciones Unidas para el Desarrollo                                                                                              |
| **PNUMA**        | Programa de las Naciones Unidas para el Medio Ambiente                                                                                          |
| **POA**          | Plan Operativo Anual                                                                                                                            |
| **PPA**          | Power Purchase Agreement (Acuerdo de Compra de Energía)                                                                                         |
| **PPD**          | Pagos por Disponibilidad                                                                                                                        |
| **PPF**          | Project Preparation Facility (Facilidad de Preparación de Proyectos)                                                                            |
| **PRI**          | Principles for Responsible Investment (Principios para la Inversión Responsable)                                                                |
| **PROAMOH**      | Proyecto de entrenamiento en sistemas de producción agrícola en zonas de montaña para técnicos agrícolas y forestales de la República de Haití  |
| **PROINDUSTRIA** | Centro de Desarrollo y Competitividad Industrial                                                                                                |
| **PROMIPYME**    | Consejo Nacional de Promoción y Apoyo a la Micro, Pequeña y Mediana Empresa                                                                     |
| **PSA**          | Pago por Servicios Ambientales                                                                                                                  |
| **PYMES**        | Pequeñas y Medianas Empresas                                                                                                                    |
| **QDMTT**        | Qualifying Domestic Minimum Top-Up Tax (Impuesto Complementario Mínimo Doméstico)                                                               |
| **RAS**          | Red de Abastecimiento Social                                                                                                                    |
| **RBF**          | Results-based Finance (Financiamiento Basado en Resultados)                                                                                     |
| **RBPC**         | Resilience Building Program for the Caribbean (Programa de Desarrollo de Resiliencia para el Caribe)                                            |
| **REDD**         | Reducing Emissions from Deforestation and Forest Degradation (Reducción de Emisiones por Deforestación y Degradación de los Bosques)            |
| **RNC**          | Registro Nacional de Contribuyentes                                                                                                             |
| **ROA**          | Return on Assets (Rentabilidad sobre Activos)                                                                                                   |
| **ROE**          | Return on Equity (Rentabilidad sobre Patrimonio)                                                                                                |
| **RPP**          | Reporte País por País                                                                                                                           |
| **RSE**          | Responsabilidad Social Empresarial                                                                                                              |
| **SAFI**         | Sociedades Administradoras de Fondos de Inversión                                                                                               |
| **SARAS**        | Sistemas de Administración de Riesgos Ambientales y Sociales                                                                                    |
| **SASB**         | Sustainability Accounting Standards Board (Consejo de Normas de Contabilidad de Sostenibilidad)                                                 |
| **SB**           | Superintendencia de Bancos                                                                                                                      |
| **SBDC**         | Small Business Development Centers (Centros de Desarrollo de Pequeñas Empresas)                                                                 |
| **SCE**          | Sistema de Comercio de Emisiones                                                                                                                |
| **SCF**          | Supply Chain Finance (Financiamiento de la Cadena de Suministro)                                                                                |
| **SDE**          | Servicios de Desarrollo Empresarial                                                                                                             |
| **SDG**          | Sustainable Development Goals (Objetivos de Desarrollo Sostenible)                                                                              |
| **SEC**          | Securities and Exchange Commission (Comisión de Bolsa y Valores de los Estados Unidos)                                                          |
| **SECP**         | Sistema Electrónico de Contrataciones Públicas                                                                                                  |
| **SEGIB**        | Secretaría General Iberoamericana                                                                                                               |
| **SEGM**         | Sistema Electrónico de Garantías Mobiliarias                                                                                                    |
| **SELA**         | Sistema Económico Latinoamericano y del Caribe                                                                                                  |
| **SFDR**         | Sustainable Finance Disclosure Regulation (Reglamento de Divulgación de Finanzas Sostenibles)                                                   |
| **SI-SINACID**   | Sistema de Información del SINACID                                                                                                              |
| **SIAFE**        | Sistema Integrado de Administración Financiera del Estado                                                                                       |
| **SIDOCAL**      | Sistema Dominicano para la Calidad                                                                                                              |
| **SIDS**         | Small Island Developing States (Pequeños Estados Insulares en Desarrollo)                                                                       |
| **SIGA**         | Sistema Integrado de Gestión Aduanera                                                                                                           |
| **SIGADE**       | Sistema de Gestión de la Deuda                                                                                                                  |
| **SIGASFL**      | Sistema Integrado de Gestión de las ASFL                                                                                                        |
| **SIGEF**        | Sistema de Información de la Gestión Financiera                                                                                                 |
| **SIGERD**       | Sistema de Información para la Gestión Escolar de la República Dominicana                                                                       |
| **SIMV**         | Superintendencia del Mercado de Valores                                                                                                         |
| **SINACID**      | Sistema Nacional de Cooperación Internacional para el Desarrollo                                                                                |
| **SIPARD**       | Sistema de Pago y Liquidación de Valores de la República Dominicana                                                                             |
| **SIPEN**        | Superintendencia de Pensiones                                                                                                                   |
| **SIS**          | Superintendencia de Seguros                                                                                                                     |
| **SISMAP**       | Sistema de Monitoreo de la Administración Pública                                                                                               |
| **SITR**         | Social Investment Tax Relief (Alivio Fiscal para la Inversión Social)                                                                           |
| **SLB**          | Bonos Vinculados a la Sostenibilidad                                                                                                            |
| **SLL**          | Préstamos Vinculados a la Sostenibilidad                                                                                                        |
| **SME**          | Small and Medium Enterprise (Pequeña y Mediana Empresa)                                                                                         |
| **SMRV**         | Sistema de Monitoreo, Reporte y Verificación                                                                                                    |
| **SN-PMR**       | Sistema Nacional de Prevención, Mitigación y Respuesta ante Desastres                                                                           |
| **SNIP**         | Sistema Nacional de Inversión Pública                                                                                                           |
| **SNPIP**        | Sistema Nacional de Planificación e Inversión Pública                                                                                           |
| **SNU**          | Sistema de las Naciones Unidas                                                                                                                  |
| **SPNF**         | Sector Público No Financiero                                                                                                                    |
| **SPO**          | Second Party Opinion (Opinión de Segundas Partes)                                                                                               |
| **SPV**          | Vehículos de Propósito Especial                                                                                                                 |
| **SSC**          | South-South Cooperation (Cooperación Sur-Sur)                                                                                                   |
| **SSM**          | Salvaguardas Sociales Mínimas                                                                                                                   |
| **STEAM**        | Science, Technology, Engineering, Arts, and Mathematics (Ciencia, Tecnología, Ingeniería, Artes y Matemáticas)                                  |
| **SWIFT**        | Society for Worldwide Interbank Financial Telecommunication (Sociedad para las Telecomunicaciones Financieras Interbancarias Mundiales)         |
| **TCFD**         | Task Force on Climate-related Financial Disclosures (Grupo de Trabajo sobre Divulgaciones Financieras Relacionadas con el Clima)                |
| **TIC**          | Tecnologías de la Información y la Comunicación                                                                                                 |
| **TIR**          | Tasa Interna de Retorno                                                                                                                         |
| **TOSSD**        | Total Official Support for Sustainable Development (Apoyo Oficial Total para el Desarrollo Sostenible)                                          |
| **TSS**          | Tesorería de la Seguridad Social                                                                                                                |
| **TVET**         | Technical and Vocational Education and Training (Educación y Formación Técnica y Profesional)                                                   |
| **UAF**          | Unidad de Análisis Financiero                                                                                                                   |
| **UE**           | Unión Europea                                                                                                                                   |
| **UNCTAD**       | United Nations Conference on Trade and Development (Conferencia de las Naciones Unidas sobre Comercio y Desarrollo)                             |
| **UNFPA**        | United Nations Population Fund (Fondo de Población de las Naciones Unidas)                                                                      |
| **UNICEF**       | United Nations Children's Fund (Fondo de las Naciones Unidas para la Infancia)                                                                  |
| **UNSPSC**       | United Nations Standard Products and Services Code (Código de Estándares de Productos y Servicios de las Naciones Unidas)                       |
| **UPI**          | Unified Payments Interface (Interfaz de Pagos Unificada)                                                                                        |
| **URBE**         | Unidad Ejecutora para la Readecuación de Barrios y Entornos                                                                                     |
| **USAID**        | United States Agency for International Development (Agencia de los Estados Unidos para el Desarrollo Internacional)                             |
| **USTR**         | United States Trade Representative (Representante Comercial de los Estados Unidos)                                                              |
| **VAN**          | Valor Actual Neto                                                                                                                               |
| **VBC**          | Viviendas de Bajo Costo                                                                                                                         |
| **VIMICI**       | Viceministerio de Cooperación Internacional                                                                                                     |
| **VIPLAN**       | Viceministerio de Planificación e Inversión Pública                                                                                             |
| **VUC**          | Ventanilla Única de Construcción                                                                                                                |
| **VUCE**         | Ventanilla Única de Comercio Exterior                                                                                                           |
| **VUI**          | Ventanilla Única de Inversión                                                                                                                   |
