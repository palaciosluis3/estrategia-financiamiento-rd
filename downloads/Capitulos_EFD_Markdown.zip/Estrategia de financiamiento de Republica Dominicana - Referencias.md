**Estrategia de financiamiento de la República Dominicana**

## 8 Referencias

***Capítulo 1: Contexto Macroeconómico y Diagnóstico Financiero***

**Banco Mundial (2025).** *The World Bank in Dominican Republic: Country Overview and Economic Outlook* . Disponible en: [https://www.bancomundial.org/es/country/dominicanrepublic/overview](https://www.bancomundial.org/es/country/dominicanrepublic/overview) .

**CADOAR (2025).** *Cifras Anuales y Trimestrales. Cámara Dominicana de Aseguradores y Reaseguradores, Inc* . Disponible en: [https://www.cadoar.org.do/services-7](https://www.cadoar.org.do/services-7) .

**CEPAL (2025).** *Estudio Económico de América Latina y el Caribe 2025: Movilización de recursos para el financiamiento del desarrollo. Comisión Económica para América Latina y el Caribe* . Disponible en: [https://www.cepal.org/es/publicaciones/82263-estudio-economico-america-latina-caribe-2025-movilizacion-recursos](https://www.cepal.org/es/publicaciones/82263-estudio-economico-america-latina-caribe-2025-movilizacion-recursos) .

**Congreso Nacional (2002).** *Ley No. 183-02 Monetaria y Financiera de la República Dominicana* . Congreso Nacional de la República Dominicana. Disponible en: [https://www.sb.gob.do/regulacion/compendio-de-leyes-y-reglamentos/ley-no-183-02-monetaria-y-financiera/](https://www.sb.gob.do/regulacion/compendio-de-leyes-y-reglamentos/ley-no-183-02-monetaria-y-financiera/) .

**Congreso Nacional (2012).** *Ley No. 1-12 Estrategia Nacional de Desarrollo 2030.* Congreso Nacional de la República Dominicana. Disponible en: [https://mepyd.gob.do/estrategia-nacional-de-desarrollo-2030/](https://mepyd.gob.do/estrategia-nacional-de-desarrollo-2030/) .

**Congreso Nacional (2017).** *Ley No. 249-17 del Mercado de Valores de la República Dominicana* . Congreso Nacional de la República Dominicana. Disponible en: [https://simv.gob.do/wpfd\_file/ley-no-249-17-del-mercado-de-valores-de-la-republica-dominicana/](https://simv.gob.do/wpfd_file/ley-no-249-17-del-mercado-de-valores-de-la-republica-dominicana/) .

**Congreso Nacional (2024).** *Ley No. 35-24 de Responsabilidad Fiscal para las Instituciones del Sector Público* . Congreso Nacional de la República Dominicana. Disponible en: [https://www.hacienda.gob.do/wp-content/uploads/2024/08/Ley-de-Responsabilidad-fiscal.pdf](https://www.hacienda.gob.do/wp-content/uploads/2024/08/Ley-de-Responsabilidad-fiscal.pdf) .

**FMI (2024).** *Dominican Republic: 2024 Article IV Consultation-Press Release and Staff Report (Country Report No. 2024/294). Fondo Monetario Internacional* . Disponible en: [https://www.imf.org/en/publications/cr/issues/2024/09/12/dominican-republic-2024-article-iv-consultation-press-release-and-staff-report-554787](https://www.imf.org/en/publications/cr/issues/2024/09/12/dominican-republic-2024-article-iv-consultation-press-release-and-staff-report-554787) .

**Fitch Ratings (2023).** *Rating Action Commentary: Fitch Revises Dominican Republic's Outlook to Positive; Affirms at 'BB-'* . Disponible en: [https://www.fitchratings.com/research/sovereigns/fitch-revises-dominican-republic-outlook-to-positive-affirms-at-bb-29-11-2023](https://www.fitchratings.com/research/sovereigns/fitch-revises-dominican-republic-outlook-to-positive-affirms-at-bb-29-11-2023) .

**MEPYD (2025).** *Boletín de estadísticas oficiales de pobreza monetaria en la República Dominicana 2024. Ministerio de Economía, Planificación y Desarrollo* . Disponible en: [https://mepyd.gob.do/publicaciones/boletin-de-estadisticas-oficiales-de-pobreza-monetaria-en-republica-dominicana-2024/](https://mepyd.gob.do/publicaciones/boletin-de-estadisticas-oficiales-de-pobreza-monetaria-en-republica-dominicana-2024/) .

**MH (2025).** *Marco Fiscal de Mediano Plazo 2024-2029 (versión abril)* . Dirección General de Análisis y Política Fiscal. Ministerio de Hacienda. Disponible en: [https://www.hacienda.gob.do/publicacion/marco-fiscal-de-mediano-plazo-2025-2029-version-abril/](https://www.hacienda.gob.do/publicacion/marco-fiscal-de-mediano-plazo-2025-2029-version-abril/) .

**MHE (2025).** *Plan Nacional Plurianual del Sector Público (PNPSP) 2025-2028.* Versión Agosto 2025. Ministerio de Hacienda y Economía. Disponible en: [https://www.hacienda.gob.do/wp-content/uploads/2025/10/Plan-Nacional-Plurianual-del-Sector-Publico-2025-2028.pdf](https://www.hacienda.gob.do/wp-content/uploads/2025/10/Plan-Nacional-Plurianual-del-Sector-Publico-2025-2028.pdf) .

**Moody's Ratings (2025).** *Rating Action: Moody's Ratings upgrades Dominican Republic's ratings to Ba2, changes outlook to stable* . Disponible en: [https://www.creditopublico.gob.do/Content/inversionistas/informes/2025/08Informe%20Moodys%20sobre%20aumento%20calificaci%C3%B3n%20crediticia%20-%20Agosto%20(en%20ingl%C3%A9s).pdf](https://www.creditopublico.gob.do/Content/inversionistas/informes/2025/08Informe%20Moodys%20sobre%20aumento%20calificaci%C3%B3n%20crediticia%20-%20Agosto%20(en%20ingl%C3%A9s).pdf) .

**S&amp;P Global Ratings (2024).** *Dominican Republic 'BB/B' Ratings Affirmed; Outlook Remains Stable* . Disponible en: [https://www.sb.gob.do/publicaciones/publicaciones-tecnicas/informe-anual-de-desempeno-del-sistema-financiero-a-diciembre-2024/](https://www.sb.gob.do/publicaciones/publicaciones-tecnicas/informe-anual-de-desempeno-del-sistema-financiero-a-diciembre-2024/) .

**SB (2025).** *Informe Anual: Desempeño del Sistema Financiero 2024. Superintendencia de Bancos* . Disponible en: [https://www.creditopublico.gob.do/Content/inversionistas/informes/2024/07Informe%20S&amp;P%20sobre%20calificaci%C3%B3n%20crediticia%20-%20Diciembre%20(en%20ingl%C3%A9s).PDF](https://www.creditopublico.gob.do/Content/inversionistas/informes/2024/07Informe%20S&P%20sobre%20calificaci%C3%B3n%20crediticia%20-%20Diciembre%20(en%20ingl%C3%A9s).PDF) .

***Capítulo 2: Finanzas Públicas Domésticas y Política Fiscal***

**Ardanaz, M., Briceño, B. y García, L.A. (2019).** *Fortaleciendo la gestión de las inversiones en América Latina y el Caribe: Lecciones aprendidas del apoyo operativo del BID a los Sistemas Nacionales de Inversión Pública (SNIP)* . Banco Interamericano de Desarrollo. Disponible en: [http://dx.doi.org/10.18235/0001952](https://dx.doi.org/10.18235/0001952) .

**Banco Mundial (2021).** *Dominican Republic - Public Expenditure Review.* Washington, D.C.: World Bank (Report No. 160636). Disponible en: [https://documents.worldbank.org/en/publication/documents-reports/documentdetail/291631623997023891](https://documents.worldbank.org/en/publication/documents-reports/documentdetail/291631623997023891)

**Bansal, R. (2021).** *Artículo 12B: una solución del tratado tributario del Comité sobre Cooperación Internacional en Cuestiones de Tributación de la ONU para la tributación de ingresos digitales* . South Centre. Disponible en: [https://www.southcentre.int/wp-content/uploads/2021/12/Tax-PB-16\_ES.pdf](https://www.southcentre.int/wp-content/uploads/2021/12/Tax-PB-16_ES.pdf) .

**Caffaro, G. (2024).** *Consultoría sobre el Marco de Financiación Integrado para República Dominicana: Propuesta de Financiación de la Estrategia Nacional de Desarrollo y las Políticas y ODS Priorizados* . Comisión Económica para America Latina y el Caribe.

**CEPAL (2020).** *Los planes nacionales de inversión pública en América Latina y el Caribe* . Comisión Económica para América Latina y el Caribe. Disponible en: [https://observatorioplanificacion.cepal.org/sites/default/files/note/files/Nota%20de%20Planificaci%C3%B3n%20N11\_0.pdf](https://observatorioplanificacion.cepal.org/sites/default/files/note/files/Nota%20de%20Planificaci%C3%B3n%20N11_0.pdf) .

**Choi, J., Carrasco, H., Cartes, F., Contreras, E., Groom, S., Mac Dowell, M. C., &amp; Tamblay, L. (2024).** *Arreglos institucionales para una gestión eficiente de la inversión pública: una revisión de los sistemas nacionales de inversión pública (SNIP) en América Latina y el Caribe y experiencias destacadas* . Armendáriz, E., Llempén, Z., &amp; Aron, S. (Eds.). Banco Interamericano de Desarrollo. Disponible en: [https://doi.org/10.18235/0013348](https://doi.org/10.18235/0013348)

**Congreso Nacional (1992).** *Ley No. 11-92 (Código Tributario de la República Dominicana).* Congreso Nacional de la República Dominicana. Disponible en: [https://dgii.gov.do/legislacion/leyesTributarias/Documents/Codigo%20Tributario%20y%20Leyes%20que%20lo%20modifican%20y%20complementan/11-92.pdf](https://dgii.gov.do/legislacion/leyesTributarias/Documents/Codigo%20Tributario%20y%20Leyes%20que%20lo%20modifican%20y%20complementan/11-92.pdf) .

**Congreso Nacional (2002).** *Ley No. 147-02 sobre Gestión de Riesgos.* Congreso Nacional de la República Dominicana. Disponible en: [https://coe.gob.do/ley-147-02/.](https://www.coe.gob.do/phocadownload/SobreNosotros/MarcoLegal/Ley_147-02_Sobre_Gestion_de_Riesgos.pdf)

**Congreso Nacional (2004).** *Ley No. 10-04 de la Cámara de Cuentas de la República Dominicana.* Congreso Nacional de la República Dominicana. Disponible en: [https://camaradediputados.gob.do/wpfd\_file/no-ley-10-04-que-crea-la-camara-de-cuentas-de-la-republica-dominicana-de-fecha-20-de-enero-de-2004/](https://camaradediputados.gob.do/wpfd_file/no-ley-10-04-que-crea-la-camara-de-cuentas-de-la-republica-dominicana-de-fecha-20-de-enero-de-2004/) .

**Congreso Nacional (2006).** *Ley No. 423-06 Orgánica de Presupuesto para el Sector Público.* Congreso Nacional de la República Dominicana. Disponible en: [https://digepres.gob.do/transparencia/wp-content/uploads/2013/06/Ley-423-06-organica-de-Presupuesto-para-el-sector-publico.pdf](https://digepres.gob.do/transparencia/wp-content/uploads/2013/06/Ley-423-06-organica-de-Presupuesto-para-el-sector-publico.pdf) .

**Congreso Nacional (2006).** *Ley No. 498-06 de Planificación e Inversión Pública* . Congreso Nacional de la República Dominicana. Disponible en: [https://camaradediputados.gob.do/wpfd\_file/no-ley-498-06-de-planificacion-e-inversion-publica-de-fecha-19-de-diciembre-2006/](https://camaradediputados.gob.do/wpfd_file/no-ley-498-06-de-planificacion-e-inversion-publica-de-fecha-19-de-diciembre-2006/) .

**DGA (2021).** *Memoria de Gestión 2020-2021* . Dirección General de Aduanas. Disponible en: [https://www.aduanas.gob.do/media/mz0ofji5/memoria-dga-2020-2021.pdf](https://www.aduanas.gob.do/media/mz0ofji5/memoria-dga-2020-2021.pdf) .

**DGII (2018).** *Estimación del Incumplimiento Tributario en la República Dominicana* . Dirección General de Impuestos Internos. Disponible en: [https://dgii.gov.do/publicacionesOficiales/estudios/Documents/2018/Incumplimiento-Tributario-en-RD.pdf](https://dgii.gov.do/publicacionesOficiales/estudios/Documents/2018/Incumplimiento-Tributario-en-RD.pdf) .

**Espíritu Mejía, R. (2025).** *Análisis sobre la Moral Tributaria en República Dominicana* . Notas Técnicas Tributarias 2025-01. Dirección General de Impuestos Internos. Disponible en: [https://dgii.gov.do/publicacionesOficiales/estudios/Documents/2025/Moral-Tributaria-2025.pdf](https://dgii.gov.do/publicacionesOficiales/estudios/Documents/2025/Moral-Tributaria-2025.pdf) .

**European Commission (2024).** *INFORM Report 2024: 10 years of INFORM: shared evidence for managing crises and disasters* . Publications Office of the European Union. Disponible en: [https://data.europa.eu/doi/10.2760/555548](https://data.europa.eu/doi/10.2760/555548) .

**FMI (2024).** *Dominican Republic: 2024 Article IV Consultation-Press Release and Staff Report* . IMF Staff Country Reports 2024, 294 (2024). Fondo Monetario Internacional. Disponible en: [https://doi.org/10.5089/9798400288708.002](https://doi.org/10.5089/9798400288708.002)

**FMI (2024).** *República Dominicana: Evaluación de la Gestión de la Inversión Pública (PIMA) y PIMA Cambio Climático (C-PIMA)* . Informe de Asistencia Técnica. Fondo Monetario Internacional.

**GFI (2021).** *Trade-Related Illicit Financial Flows in 134 Developing Countries 2009-2018* . Global Financial Integrity. Disponible en: [https://gfintegrity.org/report/trade-related-illicit-financial-flows-in-134-developing-countries-2009-2018/](https://gfintegrity.org/report/trade-related-illicit-financial-flows-in-134-developing-countries-2009-2018/) .

**Gobierno de la República Dominicana (2021).** *Compromiso Nacional para el Pacto por el Agua 2021-2036* . Santo Domingo, RD. Disponible en: [https://mepyd.gob.do/wp-content/uploads/drive/DCS/Adjuntos/PACTO%20AGUA%20%20-%20Compromiso%20Nacional%20del%20Agua%20-%20Final%2017-6-21.pdf](https://mepyd.gob.do/wp-content/uploads/drive/DCS/Adjuntos/PACTO%20AGUA%20%20-%20Compromiso%20Nacional%20del%20Agua%20-%20Final%2017-6-21.pdf) .

**IBP (2023).** *Open Budget Survey 2023: Dominican Republic Country Report.* International Budget Partnership. Disponible en: [https://internationalbudget.org/open-budget-survey/country-results/2023/dominican-republic](https://internationalbudget.org/open-budget-survey/country-results/2023/dominican-republic) .

**Impacto Economista (2024).** *Infrascopio 2023/24: Evaluación del entorno para las Alianzas Público-Privadas en América Latina y el Caribe.* Nueva York, NY. Disponible en: [https://impact.economist.com/new-globalisation/infrascope-2024/downloads/Economist\_Impact\_Infrascope\_2024\_Report\_ESP.pdf](https://impact.economist.com/new-globalisation/infrascope-2024/downloads/Economist_Impact_Infrascope_2024_Report_ESP.pdf) .

**Llempén, Z., Ardanaz, M., Valencia, O., &amp; Puig, J. (2024)** . *¿Cuánto impacta la eficiencia de la inversión pública en el crecimiento económico?: evidencia de países de América Latina y el Caribe* . Banco Interamericano de Desarrollo. Disponible en: [https://doi.org/10.18235/0013089](https://doi.org/10.18235/0013089) .

**MAUC (2023).** *Evaluación Final del Marco de Asociación País República Dominicana-España 2019-2022: Informe Final* . Evaluación y otros Estudios (No. 43). Ministerio de Asuntos Exteriores, Unión Europea y Cooperación. Disponible en: [https://www.cooperacionespanola.es/wp-content/uploads/2023/12/Informe-Final-Evaluacion-MAP-Republica-Dominicana-2019-2022.pdf](https://www.cooperacionespanola.es/wp-content/uploads/2023/12/Informe-Final-Evaluacion-MAP-Republica-Dominicana-2019-2022.pdf) .

**MEPYD (2017).** *Guía Metodológica General para la Formulación y Evaluación de Proyectos de Inversión Pública 2017.* Ministerio de Economía, Planificación y Desarrollo. Disponible en: [https://mepyd.gob.do/publicaciones/guia-metodologica-general-para-la-formulacion-y-evaluacion-de-proyectos-de-inversion-publica-2017/](https://mepyd.gob.do/publicaciones/guia-metodologica-general-para-la-formulacion-y-evaluacion-de-proyectos-de-inversion-publica-2017/) .

**MEPYD (2020).** *Plan Nacional de Infraestructura de la República Dominicana 2020-2030.* Ministerio de Economía, Planificación y Desarrollo, y Banco Interamericano de Desarrollo. Disponible en: [https://mepyd.gob.do/wp-content/uploads/drive/DIGEDES/Publicaciones/Plan%20Nacional%20de%20Infraestructura.pdf](https://mepyd.gob.do/wp-content/uploads/drive/DIGEDES/Publicaciones/Plan%20Nacional%20de%20Infraestructura.pdf) .

**MEPYD (2025).** *Plan Nacional Plurianual de Inversión Pública (PNPIP) 2025-2028.* Ministerio de Economía, Planificación y Desarrollo. Disponible en: [https://mepyd.gob.do/pnpip-2025-2028/](https://mepyd.gob.do/pnpip-2025-2028/) .

**MH (2024).** *Estrategia de Mediano Plazo para la Gestión de la Deuda Pública 2024-2028* . Dirección General de Crédito Público. Ministerio de Hacienda. Disponible en: [https://www.creditopublico.gob.do/Content/publicaciones/estrategias/04Estrategia%20de%20Gesti%C3%B3n%20de%20Deuda%20P%C3%BAblica%20de%20Mediano%20Plazo%20(2024-2028).pdf](https://www.creditopublico.gob.do/Content/publicaciones/estrategias/04Estrategia%20de%20Gesti%C3%B3n%20de%20Deuda%20P%C3%BAblica%20de%20Mediano%20Plazo%20(2024-2028).pdf) .

**MH (2024).** *Gasto Tributario en República Dominicana: Estimación para el Presupuesto General del Estado (PGE) correspondiente al período fiscal del año 2025* . Comisión Interinstitucional Coordinada por la Dirección General de Política y Legislación Tributaria. Ministerio de Hacienda. Disponible en: [https://dgii.gov.do/publicacionesOficiales/estudios/Documents/2025/Estimacion-del-Gasto-Tributario-2024-2025.pdf](https://dgii.gov.do/publicacionesOficiales/estudios/Documents/2025/Estimacion-del-Gasto-Tributario-2024-2025.pdf) .

**MH (2024).** *Marco de Gasto de Mediano Plazo 2025-2028* . Dirección General de Presupuesto. Ministerio de Hacienda. Disponible en: [https://www.digepres.gob.do/wp-content/uploads/2024/10/2.2-MGMP-2025-VF.pdf](https://www.digepres.gob.do/wp-content/uploads/2024/10/2.2-MGMP-2025-VF.pdf) .

**MH (2024).** *Marco de Referencia de Bonos Verdes, Sociales y Sostenibles de la República Dominicana* . Dirección General de Crédito Público. Ministerio de Hacienda. Disponible en: [https://www.creditopublico.gob.do/emisiones/asg](https://www.creditopublico.gob.do/emisiones/asg) .

**MH (2025).** *Marco Fiscal de Mediano Plazo 2024-2029 (versión abril)* . Dirección General de Análisis y Política Fiscal. Ministerio de Hacienda. Disponible en: [https://www.hacienda.gob.do/publicacion/marco-fiscal-de-mediano-plazo-2025-2029-version-abril/](https://www.hacienda.gob.do/publicacion/marco-fiscal-de-mediano-plazo-2025-2029-version-abril/) .

**MHE (2025).** *Panorama Macroeconómico 2025-2029 – agosto 2025* . Ministerio de Hacienda y Economía. Disponible en: [https://www.hacienda.gob.do/publicacion/marco-macroeconomico-2025-2029-agosto-2025/](https://www.hacienda.gob.do/publicacion/marco-macroeconomico-2025-2029-agosto-2025/) .

**OCDE (2021).** *OECD/G20 Base Erosion and Profit Shifting Project: Two-Pillar Solution to Address the Tax Challenges Arising from the Digitalisation of the Economy* . Organización para la Cooperación y el Desarrollo Económico. Disponible en: [https://www.pwc.com/m1/en/tax/documents/2021/two-pillar-solution-october-2021.pdf](https://www.pwc.com/m1/en/tax/documents/2021/two-pillar-solution-october-2021.pdf) .

**Presidencia de la República Dominicana (2026).** *Decreto Núm. 52-26: Reglamento de Aplicación de la Ley No. 47-25 de Contrataciones Públicas* . Disponible en: [https://www.dgcp.gob.do/new\_dgcp/documentos/politicas\_normas\_y\_procedimientos/leyes\_y\_decretos/Decreto%2052-26.pdf](https://www.dgcp.gob.do/new_dgcp/documentos/politicas_normas_y_procedimientos/leyes_y_decretos/Decreto%2052-26.pdf) .

**S&amp;P (2023).** *Second Party Opinion: Dominican Republic Green, Social, and Sustainable Bonds Framework* . Standard &amp; Poor's Global Ratings. Disponible en: [https://www.creditopublico.gob.do/Content/english/bonds\_issuance/esg/secondpartopinion/01Second%20Party%20Opinion%20-%20Dominican%20Republic's%20Green,%20Social,%20And%20Sustainable%20Bond%20Framework..pdf](https://www.creditopublico.gob.do/Content/english/bonds_issuance/esg/secondpartopinion/01Second%20Party%20Opinion%20-%20Dominican%20Republic's%20Green,%20Social,%20And%20Sustainable%20Bond%20Framework..pdf) .

**SB (2026).** *Estadísticas del Sector Financiero* . Sistema de Información del Mercado Bancario Dominicano. Superintendencia de Bancos de la República Dominicana. Disponible en: [https://simbad.sb.gob.do/superset/dashboard/inicio/](https://simbad.sb.gob.do/superset/dashboard/inicio/) .

**Tax Justice Network (2024).** *Dominican Republic: Country Profile)* . Disponible en: [https://taxjustice.net/country-profiles/dominican-republic/](https://taxjustice.net/country-profiles/dominican-republic/) .

**Vargas Pastor, C. L. y Aristizabal, N. (2021).** *República Dominicana - Revisión del Sistema Tributario* . Washington, D.C.: Banco Mundial (Informe n.º 160636). Disponible en: https://documentos.bancomundial.org/es/publication/documents-reports/documentdetail/424531623998940637

***Capítulo 3: Finanzas Públicas Internacionales y Cooperación***

**AECID (2025).** *La Cooperación Española en la República Dominicana 2025 (III)* . Agencia Española de Cooperación Internacional para el Desarrollo.

**AGCED (2025).** *República Dominicana: Reporte de los resultados del país – Ronda de monitoreo 2023-2026 de la Alianza Global* . Alianza Global para la Cooperación Eficaz al Desarrollo.

**BCIE (2021).** *Estrategia de País República Dominicana 2021-2026.* Banco Centroamericano de Integración Económica. Disponible en: [https://archive.bcie.org/fileadmin/user\_upload/Estrategia\_de\_Pais\_Republica\_Dominicana\_2021-20261\_compressed.pdf](https://archive.bcie.org/fileadmin/user_upload/Estrategia_de_Pais_Republica_Dominicana_2021-20261_compressed.pdf) .

**BID (2025).** *Acuerdo Estratégico entre República Dominicana y el Grupo BID – Estrategia País 2025-2028* . Banco Interamericano de Desarrollo. Disponible en: [https://idbinvest.org/sites/default/files/2025-09/Acuerdo%20Estrategico%20entre%20Rep.%20Dominicana%20y%20el%20Grupo%20BID%202025-2028.pdf](https://idbinvest.org/sites/default/files/2025-09/Acuerdo%20Estrategico%20entre%20Rep.%20Dominicana%20y%20el%20Grupo%20BID%202025-2028.pdf) .

**CEPAL (2024).** *América Latina y el Caribe ante las trampas del desarrollo: transformaciones indispensables y cómo gestionarlas.* Cuadragésimo periodo de sesiones de la CEPAL. Comisión Económica para América Latina y el Caribe. Disponible en: [https://hdl.handle.net/11362/80727.1](https://hdl.handle.net/11362/80727.1) .

**Congreso Nacional (2025).** *Ley No. 45-25 (Fusión de Ministerio de Hacienda y Ministerio de Economía, Planificación y Desarrollo)* . Congreso Nacional de la República Dominicana. Disponible en: [https://www.hacienda.gob.do/wp-content/uploads/2025/07/Ley-45-25.pdf](https://www.hacienda.gob.do/wp-content/uploads/2025/07/Ley-45-25.pdf) .

**European Union (2021).** *DOMINICAN REPUBLIC Multi-annual Indicative Programme 2021-2027* . Comisión de la Unión Europea. Disponible en: [https://international-partnerships.ec.europa.eu/system/files/2022-01/mip-2021-c2021-9077-dominican-republic-annex\_en.pdf](https://international-partnerships.ec.europa.eu/system/files/2022-01/mip-2021-c2021-9077-dominican-republic-annex_en.pdf) .

**Gobierno de España (2025).** *Marco de Asociación para el Desarrollo Sostenible República Dominicana-España 2025-2029* . Ministerio de Asuntos Exteriores, Unión Europea y Cooperación.

**Gobierno de la República Dominicana (2020).** *Contribución Nacionalmente Determinada de la República Dominicana (NDC-RD 2020).* Disponible en: [https://unfccc.int/sites/default/files/NDC/2022-06/Dominican%20Republic%20First%20NDC%20%28Updated%20Submission%29.pdf](https://unfccc.int/sites/default/files/NDC/2022-06/Dominican%20Republic%20First%20NDC%20%28Updated%20Submission%29.pdf) .

**Grupo Banco Mundial (2022).** *Country Partnership Framework for the Dominican Republic for the Period FY22–FY26* . Report No. 167896-DO. The World Bank Group. Disponible en: [https://documents1.worldbank.org/curated/en/366231649085796162/pdf/Dominican-Republic-Country-Partnership-Framework-for-the-Period-FY-22-26.pdf](https://documents1.worldbank.org/curated/en/366231649085796162/pdf/Dominican-Republic-Country-Partnership-Framework-for-the-Period-FY-22-26.pdf) .

**MEPYD (2016).** *Política de Cooperación Internacional para el Desarrollo de la República Dominicana* . Ministerio de Economía, Planificación y Desarrollo. Disponible en: [https://mepyd.gob.do/mepyd/wp-content/uploads/archivos/libros/politica-de-ci%20para-el-desarollo-extenso.pdf](https://mepyd.gob.do/mepyd/wp-content/uploads/archivos/libros/politica-de-ci%20para-el-desarollo-extenso.pdf) .

**MEPYD (2023).** *Catálogo Dominicano de Oferta de Cooperación Técnica* . Ministerio de Economía, Planificación y Desarrollo. Disponible en: [https://oferta-rd.mepyd.gob.do/catalogo](https://oferta-rd.mepyd.gob.do/catalogo) .

**MEPYD (2023).** *Informe Anual de Cooperación Internacional 2023.* Ministerio de Economía, Planificación y Desarrollo. Disponible en: [https://mepyd.gob.do/vimici/informes-anuales/](https://mepyd.gob.do/vimici/informes-anuales/) .

**MEPYD (2024).** *Plan Nacional Plurianual de Cooperación Internacional No Reembolsable (PNPCI) 2023-2026.* Ministerio de Economía, Planificación y Desarrollo. Disponible en: [https://mepyd.gob.do/publicacion/plan-nacional-plurianual-de-cooperacion-internacional-no-reembolsable-pnpci-2023-2026/](https://mepyd.gob.do/publicacion/plan-nacional-plurianual-de-cooperacion-internacional-no-reembolsable-pnpci-2023-2026/) .

**MEPYD (2024).** *República Dominicana también coopera: Hoja de ruta para avanzar a una política nacional de oferta de cooperación* . Ministerio de Economía, Planificación y Desarrollo. Disponible en: [https://mepyd.gob.do/wp-content/uploads/drive/VIMICI/Oferta%20Dominicana%20de%20Cooperaci%C3%B3n%20Internacional/Catalogo%20de%20Oferta%20Dominicana/Hoja%20de%20ruta%20para%20avanzar%20a%20una%20politica%20nacional%20de%20oferta.pdf](https://mepyd.gob.do/wp-content/uploads/drive/VIMICI/Oferta%20Dominicana%20de%20Cooperaci%C3%B3n%20Internacional/Catalogo%20de%20Oferta%20Dominicana/Hoja%20de%20ruta%20para%20avanzar%20a%20una%20politica%20nacional%20de%20oferta.pdf)

**MEPYD (2025).** *Informe anual de monitoreo del Plan Nacional Plurianual de Cooperación Internacional 2023* . Ministerio de Economía, Planificación y Desarrollo. Disponible en: [https://mepyd.gob.do/publicacion/informe-anual-de-monitoreo-del-plan-nacional-plurianual-de-cooperacion-internacional-2023/](https://mepyd.gob.do/publicacion/informe-anual-de-monitoreo-del-plan-nacional-plurianual-de-cooperacion-internacional-2023/) .

**MINPRE (2025).** *Nota Conceptual sobre Riesgos y Mecanismos de Solución para Fortalecer el Financiamiento del Desarrollo en la República Dominicana* . Viceministerio de Cooperación Internacional. Ministerio de la Presidencia.

**OCDE (2018).** *OECD DAC Blended Finance Principles for Unlocking Commercial Finance for the Sustainable Development Goals* . Best Practices in Development Co-operation. OECD Publishing. Organización para la Cooperación y el Desarrollo Económicos. París. Disponible en: [https://doi.org/10.1787/dc66bd9c-en](https://doi.org/10.1787/dc66bd9c-en) .

**OCDE (2026).** *TOSSD Online: Total Official Support for Sustainable Development – Data Visualization Tool* . Disponible en: https://tossd.online/.

**ONU (2023).** *Marco de Cooperación de las Naciones Unidas para el Desarrollo Sostenible 2023-2027 (República Dominicana). Naciones Unidas* . Disponible en: [https://dominicanrepublic.un.org/sites/default/files/2023-07/Marco%20de%20Cooperacio%CC%81n%20NU%202023-2027.pdf](https://dominicanrepublic.un.org/sites/default/files/2023-07/Marco%20de%20Cooperacio%CC%81n%20NU%202023-2027.pdf) .

**PEFA Secretariat (2022).** *República Dominicana 2022: Informe de evaluación de la gestión de las finanzas públicas (PEFA).* Washington, D.C.: Secretaría del PEFA. Disponible en: [https://www.pefa.org/node/5128](https://www.pefa.org/node/5128) .

**PNUD (2025).** *Nota Conceptual para contribuir al desarrollo de la estrategia financiera del Marco Integrado de Financiamiento para el Desarrollo (INFF).* Programa de las Naciones Unidas para el Desarrollo.

**Presidencia de la República Dominicana (2015).** *Decreto Núm. 267-15: Reglamento para la Organización y el Desarrollo del Sistema Nacional de Monitoreo y Evaluación (SNMyE)* . Disponible en: [https://mepyd.gob.do/wp-content/uploads/drive/Transparencia/Base%20legal%20de%20la%20institucion/decretos/Decreto%20267-15%20SNMyE.pdf](https://mepyd.gob.do/wp-content/uploads/drive/Transparencia/Base%20legal%20de%20la%20institucion/decretos/Decreto%20267-15%20SNMyE.pdf) .

**Presidencia de la República Dominicana (2020).** *Decreto Núm. 541-20 que crea el Sistema Nacional de Medición, Reporte y Verificación (MRV) de Gases de Efecto Invernadero* . Disponible en: [https://cambioclimatico.gob.do/transparencia/phocadownload/Decreto%20541-20%20-%20Que%20crea%20el%20Sistema%20Nacional%20de%20Medicion%20de%20Gases%20Efecto%20Invernadero.pdf](https://cambioclimatico.gob.do/transparencia/phocadownload/Decreto%20541-20%20-%20Que%20crea%20el%20Sistema%20Nacional%20de%20Medicion%20de%20Gases%20Efecto%20Invernadero.pdf) .

**SEGIB (2024).** *Informe de la Cooperación Sur-Sur y Triangular en Iberoamérica 2024* . Edición No. 15. Secretaría General Iberoamericana. Disponible en: [https://informesursur.org/es/report/informe-de-la-cooperacion-sur-sur-y-triangular-en-iberoamerica-2024/](https://informesursur.org/es/report/informe-de-la-cooperacion-sur-sur-y-triangular-en-iberoamerica-2024/) .

**Sianes, A., Santos-Carrillo, F. y Fernández-Portillo, L. A. (2024).** *La Agenda 2030 en marcha: desafíos de implementación en República Dominicana* . América Latina Hoy, 94, e31718. Disponible en: [https://doi.org/10.14201/alh.31718](https://doi.org/10.14201/alh.31718) .

**UE (2021).** *Multiannual Indicative Programme (MIP) 2021-2027 for the Dominican Republic.* Unión Europea. Disponible en: [https://international-partnerships.ec.europa.eu/countries/dominican-republic\_en](https://international-partnerships.ec.europa.eu/countries/dominican-republic_en) .

***Capítulo 4: Finanzas Privadas y Movilización de Capital***

**ADOSAFI (2025).** *Fondos de Inversión en República Dominicana.* Diciembre 2025. Asociación Dominicana de Sociedades Administradoras de Fondos de Inversión. Disponible en: [https://adosafi.org/wp-content/uploads/2026/02/Boletin-Dic-2025.pdf](https://adosafi.org/wp-content/uploads/2026/02/Boletin-Dic-2025.pdf) .

**Alibhai, S., Bell, S. y Conner, G. (2017).** *What's Happening in the Missing Middle? Lessons from Financing SMEs* . Alibhai, Salman; Bell, Simon; Conner, Gillette, editors.  Banco Mundial. License: CC BY 3.0 IGO. Disponible en: [https://doi.org/10.1596/26324](https://doi.org/10.1596/26324) .

**BCRD (2023).** *Encuesta Nacional de Inclusión y Educación Financiera (ENIEF) 2023 (Resumen Ejecutivo).* Departamento de Regulación y Estabilidad Financiera. Banco Central de la República Dominicana. Disponible en: [https://cdn.bancentral.gov.do/documents/sala-de-prensa/noticias/documents/Resumen-Ejecutivo-ENIEF-2023.pdf?v=1779121138555](https://cdn.bancentral.gov.do/documents/sala-de-prensa/noticias/documents/Resumen-Ejecutivo-ENIEF-2023.pdf?v=1779121138555) .

**BCRD (2024).** *Informe Encuesta Nacional de Inclusión y Educación Financiera 2024* . Banco Central de la República Dominicana. Departamento de Regulación y Estabilidad Financiera. Banco Central de la República Dominicana. Disponible en: [https://cdn.bancentral.gov.do/documents/otras-publicaciones/documents/Informe\_de\_Encuesta\_Nacional\_de\_Inclusion.pdf](https://cdn.bancentral.gov.do/documents/otras-publicaciones/documents/Informe_de_Encuesta_Nacional_de_Inclusion.pdf) .

**BCRD y MICM (2024).** *Las Micro, Pequeñas y Medianas Empresas en República Dominicana 2022-2023: Barrido de Identificación de Establecimientos y Encuesta Nacional MIPYMES* . Banco Central de la República Dominicana y Ministerio de Industria, Comercio y Mipymes. Disponible en: [https://cdn.bancentral.gov.do/documents/otras-publicaciones/documents/ENMIPYMES-Documento-principales-resultados-aspectos-metodologicos.pdf?v=1779121302224](https://cdn.bancentral.gov.do/documents/otras-publicaciones/documents/ENMIPYMES-Documento-principales-resultados-aspectos-metodologicos.pdf?v=1779121302224) .

**Brito Cardoso, D., De Almeida Papa, U., Donovan, M., Palominos Aravena, O., Pella, P., Dickson Morales, R., Bagnoli, V., Rehbein, A. R., &amp; Olivera, M. L. (2021).** *Las APP y los órganos de control en América Latina y el Caribe: roles y desafíos* . Carvalho Metanias Hallack, M., &amp; Sampaio, P. (Eds.). Banco Interamericano de Desarrollo. Disponible en: [https://doi.org/10.18235/0003810](https://doi.org/10.18235/0003810)

**Better Society Capital (2024).** *Impact Report 2023* . Londres. Better Society Capital. Disponible en: [https://bettersocietycapital.com/impact-report-2023/](https://bettersocietycapital.com/impact-report-2023/) .

**CAF (2021).** *Blended Finance 2021* . Dirección de Recursos Financieros Institucionales. Banco de Desarrollo de América Latina. Disponible en: [https://www.caf.com/media/3382110/drfi-financiamiento-mixto.pdf](https://www.caf.com/media/3382110/drfi-financiamiento-mixto.pdf) .

**CIF (2022).** *Estrategia Nacional de Inclusión Financiera 2022-2030* . Primera Edición. Comisión de Inclusión Financiera. Disponible en: [https://cdn.bancentral.gov.do/documents/ENIF\_V3.pdf](https://cdn.bancentral.gov.do/documents/ENIF_V3.pdf) .

**CNC (2021).** *Estrategia Nacional de Competitividad: Hacia el sueño dominicano* . Consejo Nacional de Competitividad. Disponible en: [https://cnc.gob.do/wp-content/uploads/2022/07/ESTRATEGIA\_NACIONAL\_DE\_COMPETITIVIDAD.pdf](https://cnc.gob.do/wp-content/uploads/2022/07/ESTRATEGIA_NACIONAL_DE_COMPETITIVIDAD.pdf) .

**CNC (2025).** *Informe de Riesgos Globales 2025* . Consejo Nacional de Competitividad. Disponible en: [https://cnc.gob.do/wp-content/uploads/2025/10/Informe-de-Riesgos-Globales-2025.pdf](https://cnc.gob.do/wp-content/uploads/2025/10/Informe-de-Riesgos-Globales-2025.pdf) .

**CNC (2025).** *Resumen de avance de la Estrategia Nacional de Competitividad* . Consejo Nacional de Competitividad. Disponible en: [https://cnc.gob.do/ova\_doc/resumen-de-avance-de-la-estrategia-nacional-de-competitividad-sept-2025/](https://cnc.gob.do/ova_doc/resumen-de-avance-de-la-estrategia-nacional-de-competitividad-sept-2025/)

**Congreso Nacional (2001).** *Ley No. 87-01 que crea el Sistema Dominicano de Seguridad Social* . Congreso Nacional de la República Dominicana. Disponible en: [https://www.digepres.gob.do/wp-content/uploads/2019/08/Ley-87-01-que-crea-el-Sistema-Nacional-de-Seguridad-Social.pdf](https://www.digepres.gob.do/wp-content/uploads/2019/08/Ley-87-01-que-crea-el-Sistema-Nacional-de-Seguridad-Social.pdf) .

**Congreso Nacional (2002).** *Ley No. 146-02 sobre Seguros y Fianzas de la República Dominicana* . Congreso Nacional de la República Dominicana. Disponible en: [https://docs.republica-dominicana.justia.com/nacionales/leyes/ley-146-02.pdf](https://docs.republica-dominicana.justia.com/nacionales/leyes/ley-146-02.pdf) .

**Congreso Nacional (2008).** *Ley No. 479-08 de Sociedades Comerciales y Empresas Individuales de Responsabilidad Limitada* . Congreso Nacional de la República Dominicana. Disponible en: [https://dgii.gov.do/legislacion/leyesTributarias/Documents/Otras%20Leyes%20de%20Inter%C3%A9s/479-08.pdf](https://dgii.gov.do/legislacion/leyesTributarias/Documents/Otras%20Leyes%20de%20Inter%C3%A9s/479-08.pdf) .

**Congreso Nacional (2011).** *Ley No. 189-11 para el Desarrollo del Mercado Hipotecario y el Fideicomiso* . Congreso Nacional de la República Dominicana. Disponible en: [https://ri.gob.do/wp-content/uploads/Marco\_Legal/Leyes/Ley\_189-11.pdf](https://ri.gob.do/wp-content/uploads/Marco_Legal/Leyes/Ley_189-11.pdf) .

**Congreso Nacional (2016).** *Ley No. 688-16 de Emprendimiento* . Congreso Nacional de la República Dominicana. Disponible en: [https://micm.gob.do/transparencia/images/pdf/transparencia/base-legal-de-la-institucion/resoluciones/Leyes/2016/Ley\_no.\_688\_16.pdf](https://micm.gob.do/transparencia/images/pdf/transparencia/base-legal-de-la-institucion/resoluciones/Leyes/2016/Ley_no._688_16.pdf) .

**Congreso Nacional (2020).** *Ley No. 47-20 de Alianzas Público-Privadas* . Congreso Nacional de la República Dominicana. Disponible en: [https://dgii.gov.do/legislacion/leyesTributarias/Documents/Otras%20Leyes%20de%20Inter%C3%A9s/47-20.pdf](https://dgii.gov.do/legislacion/leyesTributarias/Documents/Otras%20Leyes%20de%20Inter%C3%A9s/47-20.pdf) .

**Congreso Nacional (2023).** *Ley No. 28-23 sobre Fideicomiso Público* . Congreso Nacional de la República Dominicana. Disponible en: [https://presidencia.gob.do/libraries/pdf.js/web/viewer.html?file=https%3A%2F%2Fpresidencia.gob.do%2Fsites%2Fdefault%2Ffiles%2Flaws%2F2023-03%2FLey%252028-23%252C%2520sobre%2520Fideicomiso%2520pu%25CC%2581blico.pdf](https://presidencia.gob.do/libraries/pdf.js/web/viewer.html?file=https%3A%2F%2Fpresidencia.gob.do%2Fsites%2Fdefault%2Ffiles%2Flaws%2F2023-03%2FLey%252028-23%252C%2520sobre%2520Fideicomiso%2520pu%25CC%2581blico.pdf) .

**DGAPP (2022).** *Memoria Institucional 2022* . Dirección General de Alianzas Público-Privadas. Disponible en: [https://transparencia.dgapp.gob.do/index.php/plan-estrategico/memorias-institucionales](https://transparencia.dgapp.gob.do/index.php/plan-estrategico/memorias-institucionales) .

**DGII (2024).** *Boletín Mipymes 2024* . Gerencia de Estudios Económicos y Tributarios. Dirección General de Impuestos Internos. Disponible en: [https://dgii.gov.do/estadisticas/Boletin%20Mipymes/Bolet%C3%ADn-MIPYMES-2024.pdf](https://dgii.gov.do/estadisticas/Boletin%20Mipymes/Bolet%C3%ADn-MIPYMES-2024.pdf) .

**European Union (2019).** *Regulation (EU) 2019/2088 of the European Parliament and of the Council of 27 November 2019 on sustainability‐related disclosures in the financial services sector* . European Union. Disponible en: [https://eur-lex.europa.eu/eli/reg/2019/2088/oj/eng](https://eur-lex.europa.eu/eli/reg/2019/2088/oj/eng) .

**GIIN (2026).** *An Introduction to Impact Measurement and Management.* Global Impact Investing Network. Disponible en: [https://iris.thegiin.org/introduction/](https://iris.thegiin.org/introduction/) .

**GRI (2026).** *GRI Standards by language* . Global Reporting Initiative Disponible en: [https://www.globalreporting.org/standards/download-the-standards/](https://www.globalreporting.org/standards/download-the-standards/) .

**Gobierno de la República de Francia (2019).** *LOI n° 2019-486 du 22 mai 2019 relative à la croissance et à la transformation des empresas (Loi PACTE)* . Disponible en: [https://www.legifrance.gouv.fr/loda/id/JORFTEXT000038496102](https://www.legifrance.gouv.fr/loda/id/JORFTEXT000038496102) .

**Godfrey, C. (2024).** *Social Investment Tax Relief (SITR) explained* . Swoop Funding. Disponible en: [https://swoopfunding.com/uk/equity-financing/sitr-social-investment-tax-relief/](https://swoopfunding.com/uk/equity-financing/sitr-social-investment-tax-relief/) .

**IFC (2021).** *Using Blended Concessional Finance to Invest in Challenging Markets: Economic Considerations, Transparency, Governance, and Lessons of Experience* . Washington, D.C. International Finance Corporation. World Bank Group. Disponible en: [https://www.ifc.org/content/dam/ifc/doc/mgrt/ifc-blendedfinance-fin-092021.pdf](https://www.ifc.org/content/dam/ifc/doc/mgrt/ifc-blendedfinance-fin-092021.pdf) .

**IFRS (2023).** *IFRS S1: General Requirements for Disclosure of Sustainability-related Financial Information: Climate-related Disclosures.* International Sustainability Standards Board. Disponible en: [https://www.ifrs.org/content/dam/ifrs/publications/pdf-standards-issb/english/2023/issued/part-a/issb-2023-a-ifrs-s1-general-requirements-for-disclosure-of-sustainability-related-financial-information.pdf?bypass=on](https://www.ifrs.org/content/dam/ifrs/publications/pdf-standards-issb/english/2023/issued/part-a/issb-2023-a-ifrs-s1-general-requirements-for-disclosure-of-sustainability-related-financial-information.pdf?bypass=on) .

**MEPYD (2017).** *Las Alianzas Público-Privadas para el Desarrollo Sostenible: Una apuesta de impulso al desarrollo de la República Dominicana* . Ministerio de Economía, Planificación y Desarrollo. Disponible en: [https://mepyd.gob.do/wp-content/uploads/drive/VIMICI/Infografias/APPDS%20MEPyD%20WEB.pdf](https://mepyd.gob.do/wp-content/uploads/drive/VIMICI/Infografias/APPDS%20MEPyD%20WEB.pdf) .

**MICM (2022).** *Proyecto Fortalecimiento de la Calidad para el Desarrollo de las Mipymes (SNIP 13792) - Informe de cierre al seguimiento del proyecto* . Ministerio de Industria, Comercio y Mipymes. Disponible en: [https://www.micm.gob.do/transparencia/mapa-de-documentos/snip-13792-informe-final-al-seguimiento-calidad-pdf](https://www.micm.gob.do/transparencia/mapa-de-documentos/snip-13792-informe-final-al-seguimiento-calidad-pdf) .

**OCDE (2024).** *Pension Markets in Focus 2024* . OECD Publishing. Paris. Disponible en: [https://doi.org/10.1787/b11473d3-en](https://doi.org/10.1787/b11473d3-en) .

**ONE (2016).** *Estudio sobre el Impacto de las Microfinanzas en el Bienestar Social de República Dominicana 2015* . Oficina Nacional de Estadística y Fundación Reservas del País. Disponible en: [https://www.one.gob.do/publicaciones/2016/estudio-sobre-el-impacto-de-las-microfinanzas-en-el-bienestar-social-de-republica-dominicana-2015/](https://www.one.gob.do/publicaciones/2016/estudio-sobre-el-impacto-de-las-microfinanzas-en-el-bienestar-social-de-republica-dominicana-2015/) .

**Pioneer Funds (2019).** *Prospecto de Emisión – Fondo Cerrado de Desarrollo de Sociedades Pioneer* . Pioneer Funds. Disponible en: [https://pioneerfunds.do/download/prospecto-de-emision/](https://pioneerfunds.do/download/prospecto-de-emision/) .

**PNUMA (2015).** *Sistema de Categorización para el Financiamiento Circular en la República Dominicana* . Finance Initiative. UN Environment Programme. Disponible en: [https://www.unepfi.org/wordpress/wp-content/uploads/2025/11/LAC\_Dominican-Republic\_Sistema-de-Categorizacion.pdf](https://www.unepfi.org/wordpress/wp-content/uploads/2025/11/LAC_Dominican-Republic_Sistema-de-Categorizacion.pdf) .

**Presidencia de la República Dominicana (2020).** *Decreto No. 434-20: Reglamento de aplicación de la ley 47-20 de Alianzas Público-Privadas* . Presidencia de la República Dominicana. Disponible en: [https://dgapp.gob.do/wp-content/uploads/2020/09/Reglamento-de-aplicacion-de-la-Ley-47-20-de-Alianzas-Publico-Privadas.pdf](https://dgapp.gob.do/wp-content/uploads/2020/09/Reglamento-de-aplicacion-de-la-Ley-47-20-de-Alianzas-Publico-Privadas.pdf) .

**Presidencia de la República Dominicana (2022).** *Decreto Núm. 31-22 que fomenta las compras gubernamentales a las MiPymes industriales* . Presidencia de la República Dominicana. Disponible en: [https://transparencia.mived.gob.do/images/Base\_legal/Decretos/Decreto\_31-22.pdf](https://transparencia.mived.gob.do/images/Base_legal/Decretos/Decreto_31-22.pdf) .

**ProTEVI (2025).** *Nota Conceptual: Articulación de los Programas de Responsabilidad Social Empresarial con el Sistema Nacional de Planificación* . Marco Nacional Integrado de Financiamiento para el Desarrollo Sostenible (INFF).

**IFRS (2026).** *Fundamentos de las Conclusiones sobre las modificaciones propuestas a las Normas del SASB* . International Sustainability Standards Board (ISSB). Disponible en: [https://www.ifrs.org/content/dam/ifrs/project/enhancing-the-sasb-standards/es-sasb-ed-2025-1-bc-proposed-amends.pdf](https://www.ifrs.org/content/dam/ifrs/project/enhancing-the-sasb-standards/es-sasb-ed-2025-1-bc-proposed-amends.pdf) .

**SB (2025).** *Financiamiento a las Micro, Pequeñas y Medianas Empresas (Marzo 2025).* Departamento de Estudios Económicos. Superintendencia de Bancos. Disponible en: [https://www.sb.gob.do/media/jqslfhci/informe-mipymes-mar-25.pdf](https://www.sb.gob.do/media/jqslfhci/informe-mipymes-mar-25.pdf) .

**SIMV (2026).** *Estadísticas del Mercado de Valores en formato dinámico.* Superintendencia del Mercado de Valores de la República Dominicana. Disponible en: [https://simv.gob.do/estadisticas-reportes-y-estudios/](https://simv.gob.do/estadisticas-reportes-y-estudios/) .

**SIMV (2025).** *Guía práctica para la emisión de valores temáticos* . Santo Domingo: SIMV. Superintendencia del Mercado de Valores de la República Dominicana. Disponible en: [https://simv.gob.do/wpfd\_file/guia-practica-para-la-emision-de-valores-tematicos/](https://simv.gob.do/wpfd_file/guia-practica-para-la-emision-de-valores-tematicos/) .

**SIPEN (2024).** *Boletín Estadístico Trimestral No. 90 República Dominicana 2025.* Superintendencia de Pensiones. Disponible en: [https://sipen.gob.do/publicaciones/boletines-trimestrales](https://sipen.gob.do/publicaciones/boletines-trimestrales) .

**SIS (2025).** *Reportes Estadísticos. Superintendencia de Seguros* . Disponible en: [https://sis.gob.do/reportes-estadisticos/](https://sis.gob.do/reportes-estadisticos/) .

**TCFD (2023).** *2023 TCFD Status Report: Task Force on Climate-related Financial Disclosures* . Disponible en: [https://www.fsb.org/uploads/P121023-2.pdf](https://www.fsb.org/uploads/P121023-2.pdf) .

***Capítulo 5: Inversión con Propósito y Sostenibilidad***

**ADB (2023).** *2023 Trade Finance Gaps, Growth, and Jobs Survey (ADB Brief No. 256).* Asian Development Bank. Disponible en: [https://www.adb.org/sites/default/files/publication/906596/adb-brief-256-2023-trade-finance-gaps-growth-jobs-survey.pdf](https://www.adb.org/sites/default/files/publication/906596/adb-brief-256-2023-trade-finance-gaps-growth-jobs-survey.pdf) .

**ADOZONA, ECONOMI-K y ANALYTICA (2012).** *Impacto Económico y Social de las Zonas Francas: Una Visión de 360 Grados – República Dominicana* . Sistema Económico Latinoamericano y del Caribe (SELA). Disponible en: [https://www.sela.org/publicaciones/impacto-economico-y-social-de-las-zonas-francas-una-vision-de-360-grados-repubica-dominicana/](https://www.sela.org/publicaciones/impacto-economico-y-social-de-las-zonas-francas-una-vision-de-360-grados-repubica-dominicana/)

**AIRD (2024).** *Tejido Productivo de la Manufactura Local Dominicana: Encadenamientos, Empleo e Impacto Económico.* Asociación de Industrias de la República Dominicana. Disponible en: [https://aird.org.do/es/publicaciones/estudios/tejido-productivo-de-la-manufactura-local-dominicana](https://aird.org.do/es/publicaciones/estudios/tejido-productivo-de-la-manufactura-local-dominicana) .

**BCRD (2025).** *BCRD informa que los flujos de remesas alcanzaron US$11,866.3 millones en 2025.* Banco Central de la República Dominicana. Disponible en: [https://www.bancentral.gov.do/a/d/6463-bcrd-informa-que-los-flujos-de-remesas-alcanzaron-us118663-millones-en-2025](https://www.bancentral.gov.do/a/d/6463-bcrd-informa-que-los-flujos-de-remesas-alcanzaron-us118663-millones-en-2025) .

**BCRD (2025).** *Resiliencia económica y atracción de inversión extranjera directa en República Dominicana ante la incertidumbre global* . Banco Central de la República Dominicana. Disponible en: [https://www.bancentral.gov.do/a/d/6422-resiliencia-economica-y-atraccion-de-inversion-extranjera-directa-en-republica-dominicana-ante-la-incertidumbre-global](https://www.bancentral.gov.do/a/d/6422-resiliencia-economica-y-atraccion-de-inversion-extranjera-directa-en-republica-dominicana-ante-la-incertidumbre-global) .

**BCRD (2026).** *La inversión extranjera directa alcanzó los US$5,032.3 millones al cierre de 2025* . Banco Central de la República Dominicana. Disponible en: [https://www.bancentral.gov.do/a/d/6482-bcrd-informa-que-la-inversion-extranjera-directa-alcanzo-los-us50323-millones-al-cierre-de-2025](https://www.bancentral.gov.do/a/d/6482-bcrd-informa-que-la-inversion-extranjera-directa-alcanzo-los-us50323-millones-al-cierre-de-2025) .

**Banco Mundial (2023).** *Connecting to Compete 2023: Trade Logistics in the Global Economy* . Disponible en: [https://documents1.worldbank.org/curated/en/099042123145531599/pdf/P17146804a6a570ac0a4f80895e320dda1e.pdf](https://documents1.worldbank.org/curated/en/099042123145531599/pdf/P17146804a6a570ac0a4f80895e320dda1e.pdf) .

**Bancóldex (2026).** *Reporte de Sostenibilidad 2025* . Disponible en: [https://www.bancoldex.com/sites/default/files/2026-04/Reporte%20Sostenibilidad%202025.pdf](https://www.bancoldex.com/sites/default/files/2026-04/Reporte%20Sostenibilidad%202025.pdf) .

**Brito, S. y López, J. C. (2024).** *BIDeconomics República Dominicana 2024: Panorama de oportunidades* . Gómez Osorio, A. (Ed.). Banco Interamericano de Desarrollo. Disponible en: [https://doi.org/10.18235/0013178](https://doi.org/10.18235/0013178) .

**CEPAL (2024).** *América Latina y el Caribe ante las trampas del desarrollo: transformaciones indispensables y cómo gestionarlas* . Comisión Económica para América Latina y el Caribe. Disponible en: [https://www.cepal.org/es/publicaciones/80727-america-latina-caribe-trampas-desarrollo-transformaciones-indispensables-como](https://www.cepal.org/es/publicaciones/80727-america-latina-caribe-trampas-desarrollo-transformaciones-indispensables-como) .

**CNZFE (2025).** *Informe Estadístico 2024: Zonas Francas en la República Dominicana.* Consejo Nacional de Zonas Francas de Exportación. Disponible en: [https://cnzfe.gob.do/wp-content/uploads/2025/08/Informe-Estadistico-2024.pdf](https://cnzfe.gob.do/wp-content/uploads/2025/08/Informe-Estadistico-2024.pdf) .

**Congreso Nacional (1995).** *Ley No. 16-95 sobre Inversión Extranjera en la República Dominicana* . Congreso Nacional de la República Dominicana. Disponible en: [https://dgii.gov.do/legislacion/leyesTributarias/Documents/Leyes%20de%20Incentivos%20y%20Fomentos/16-95.pdf](https://dgii.gov.do/legislacion/leyesTributarias/Documents/Leyes%20de%20Incentivos%20y%20Fomentos/16-95.pdf) .

**Congreso Nacional (2001).** *Ley No. 158-01 de Fomento al Desarrollo Turístico (CONFOTUR)* . Congreso Nacional de la República Dominicana. Disponible en: [https://dgii.gov.do/legislacion/leyesTributarias/Documents/Leyes%20de%20Incentivos%20y%20Fomentos/158-01.pdf](https://dgii.gov.do/legislacion/leyesTributarias/Documents/Leyes%20de%20Incentivos%20y%20Fomentos/158-01.pdf) .

**Congreso Nacional (2007).** *Ley No. 57-07 de Incentivo al Desarrollo de Fuentes Renovables de Energía* . Congreso Nacional de la República Dominicana. Disponible en: [https://dgii.gov.do/legislacion/leyesTributarias/Documents/Leyes%20de%20Incentivos%20y%20Fomentos/57-07.pdf](https://dgii.gov.do/legislacion/leyesTributarias/Documents/Leyes%20de%20Incentivos%20y%20Fomentos/57-07.pdf) .

**Congreso Nacional (2011).** *Ley No. 189-11 para el Desarrollo del Mercado Hipotecario y el Fideicomiso* . Congreso Nacional de la República Dominicana. Disponible en: [https://ri.gob.do/wp-content/uploads/Marco\_Legal/Leyes/Ley\_189-11.pdf](https://ri.gob.do/wp-content/uploads/Marco_Legal/Leyes/Ley_189-11.pdf) .

**Congreso Nacional (2020).** *Ley No. 47-20 de Alianzas Público-Privadas* . Congreso Nacional de la República Dominicana. Disponible en: [https://dgii.gov.do/legislacion/leyesTributarias/Documents/Otras%20Leyes%20de%20Inter%C3%A9s/47-20.pdf](https://dgii.gov.do/legislacion/leyesTributarias/Documents/Otras%20Leyes%20de%20Inter%C3%A9s/47-20.pdf) .

**Congreso Nacional (2021).** *Ley No. 122-21 de Transformación del BANDEX* . Congreso Nacional de la República Dominicana. Disponible en: [https://www.consultoria.gov.do/Consulta/Home/FileManagement?documentId=3398227&amp;managementType=1](https://www.consultoria.gov.do/Consulta/Home/FileManagement?documentId=3398227&managementType=1) .

**Congreso Nacional (2022).** *Ley No. 12-21 que crea la Zona Especial de Desarrollo Integral Fronterizo* . Congreso Nacional de la República Dominicana. Disponible en: [https://dgii.gov.do/legislacion/leyesTributarias/Documents/Leyes%20de%20Incentivos%20y%20Fomentos/12-21.pdf](https://dgii.gov.do/legislacion/leyesTributarias/Documents/Leyes%20de%20Incentivos%20y%20Fomentos/12-21.pdf) .

**Consejo Nacional de la Competitividad (2023).** *Índice de Desempeño Logístico (LPI) del Banco Mundial 2023* . Presidencia de la República Dominicana. Disponible en: [https://cnc.gob.do/wp-content/uploads/2023/07/Indice-de-Desempeno-Logistico-2023.pdf](https://cnc.gob.do/wp-content/uploads/2023/07/Indice-de-Desempeno-Logistico-2023.pdf) .

**Gobierno de la República Dominicana (2020).** *Plan Nacional de Fomento a las Exportaciones 2020-2030* . Disponible en: [https://prointeligencia.prodominicana.gob.do/apiv2/data/post/9302dc06-011e-4273-88d8-7d400a9f56c5/pdf/PD%20PNFERD%20W.pdf](https://prointeligencia.prodominicana.gob.do/apiv2/data/post/9302dc06-011e-4273-88d8-7d400a9f56c5/pdf/PD%20PNFERD%20W.pdf) .

**MICM (2021).** *Estrategia Nacional de Exportación de Servicios Modernos.* Ministerio de Industria, Comercio y Mipymes. Disponible en: [https://micm.gob.do/transparencia/images/pdf/publicaciones/libros/informes/2021/10-octubre/Informe\_Servicios\_Modernos\_octubre\_2021.pdf](https://micm.gob.do/transparencia/images/pdf/publicaciones/libros/informes/2021/10-octubre/Informe_Servicios_Modernos_octubre_2021.pdf) .

**MICM (2024).** *Estrategia Nacional de Fomento a la Industria de Semiconductores (ENFIS).* Ministerio de Industria, Comercio y Mipymes. Disponible en: [https://micm.gob.do/wp-content/uploads/2025/08/Estrategia-Nacional-de-Fomento-a-la-Industria-de-Semiconductores-ENFIS.pdf](https://micm.gob.do/wp-content/uploads/2025/08/Estrategia-Nacional-de-Fomento-a-la-Industria-de-Semiconductores-ENFIS.pdf) .

**MH (2024).** *Gasto Tributario en República Dominicana: Estimación para el Presupuesto General del Estado (PGE) correspondiente al período fiscal del año 2025* . Comisión Interinstitucional Coordinada por la Dirección General de Política y Legislación Tributaria. Ministerio de Hacienda. Disponible en: [https://dgii.gov.do/publicacionesOficiales/estudios/Documents/2025/Estimacion-del-Gasto-Tributario-2024-2025.pdf](https://dgii.gov.do/publicacionesOficiales/estudios/Documents/2025/Estimacion-del-Gasto-Tributario-2024-2025.pdf) .

**OCDE (2025).** *Evaluación del impacto socioeconómico de la inversión extranjera directa en América Latina y el Caribe: Un enfoque en las inversiones de la UE* . OECD Publishing. Paris. Disponible en: [https://doi.org/10.1787/13c7d291-es](https://doi.org/10.1787/13c7d291-es) .

**OMC (2023).** *Trade Policy Review: Dominican Republic (Fifth Review).* Organización Mundial del Comercio. Disponible en: [https://www.wto.org/english/tratop\_e/tpr\_e/tp542\_e.htm](https://www.wto.org/english/tratop_e/tpr_e/tp542_e.htm) .

**PNUD (2024).** *Mapa de Oportunidades de Inversión alineadas con los ODS (República Dominicana)* . Programa de las Naciones Unidas para el Desarrollo. Disponible en: [https://www.undp.org/es/dominican-republic/mapa-de-oportunidades-de-inversion-ods-para-el-sector-privado-rd](https://www.undp.org/es/dominican-republic/mapa-de-oportunidades-de-inversion-ods-para-el-sector-privado-rd) .

**ProDominicana (2024).** *Guía de Inversión de la República Dominicana 2025* . Centro de Exportación e Inversión de la República Dominicana. Gobierno de la República Dominicana. Disponible en: [https://prodominicana.gob.do/Documentos/Guia\_de\_Inversion\_%20RD\_en\_Espanol.pdf](https://prodominicana.gob.do/Documentos/Guia_de_Inversion_%20RD_en_Espanol.pdf) .

**U.S. Department of State (2024).** *2024 Investment Climate Statements: Dominican Republic* . United States Department of State. Disponible en: [https://www.state.gov/reports/2024-investment-climate-statements/dominican-republic](https://www.state.gov/reports/2024-investment-climate-statements/dominican-republic) .

**USTR (2024).** *2024 National Trade Estimate Report on Foreign Trade Barriers.* United States Trade Representative. Disponible en: [https://ustr.gov/sites/default/files/2024%20NTE%20Report.pdf](https://ustr.gov/sites/default/files/2024%20NTE%20Report.pdf) .

**Vergara M., S. (2004).** *La inversión extranjera directa en República Dominicana y su impacto sobre la competitividad de sus exportaciones* . Comisión Económica para América Latina y el Caribe (CEPAL). Disponible en: [https://hdl.handle.net/11362/4545](https://hdl.handle.net/11362/4545)

***Capítulo 6: Ventanas de Financiamiento e Innovación***

**Carvajal, I. y Guzman, S. (2026).** *Entregable II - Informe de Mecanismos Alternativos de Financiamiento.* Marco Nacional Integrado de Financiamiento (INFF). Apoyo de CEPAL.